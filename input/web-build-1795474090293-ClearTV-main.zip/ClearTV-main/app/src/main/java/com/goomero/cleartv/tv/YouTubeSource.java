package com.goomero.cleartv.tv;

import android.content.Context;
import android.util.JsonReader;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * YouTube through its own TV API (youtubei, the TVHTML5 client the living-room app uses): the same home, topic,
 * Movies & TV, channel and search shelves as YouTube on a TV. Ad slots in those answers are dropped; everything
 * else is shown. Live streams ask the iOS client for an HLS stream (plain H.264/AAC, no DRM) for ClearTV's player;
 * videos plays in YouTube's embed player inside ClearTV (WebActivity).
 * Sign-in is YouTube's TV device code (google.com/device), the tokens kept in this app's private storage.
 */
final class YouTubeSource extends Source {
    private static final String TAG = "CTV.YouTube";
    // endpoints, client versions, OAuth client and parser keys come from the bundled config (Config)
    private static String API, TV_CLIENT, TV_VERSION, IOS_CLIENT, IOS_VERSION, CLIENT_ID, CLIENT_SECRET, DEVICE_CODE_URL,
            TOKEN_URL, SCOPE;
    static String IOS_UA;
    private static Set<String> CAPTURE, SKIP;
    /** SKIP without the tile menus: signed in, a tile's long-press menu carries its "Don't recommend channel". */
    private static volatile Set<String> SKIP_MENU;
    /** Labels of that menu entry (lower case, straight apostrophe). */
    private static volatile String[] HIDE_LABELS;
    private static final Set<String> NONE = new HashSet<>();
    private static final String SHORTS = "shorts";

    static {
        Config.onChange(new Runnable() {
            @Override
            public void run() {
                API = Config.s("youtube.api", "https://www.youtube.com/youtubei/v1/");
                TV_CLIENT = Config.s("youtube.tvClientName", "TVHTML5");
                TV_VERSION = Config.s("youtube.tvClientVersion", "7.20261015.10.00");
                IOS_CLIENT = Config.s("youtube.iosClientName", "IOS");
                IOS_VERSION = Config.s("youtube.iosClientVersion", "20.10.4");
                IOS_UA = Config.s("youtube.iosUserAgent", "com.google.ios.youtube/{v} (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)")
                        .replace("{v}", IOS_VERSION);
                // the YouTube TV app's public OAuth client (device flow); it ships in every TV app
                CLIENT_ID = Config.s("youtube.oauthClientId", "861556708454-d6dlm3lh05idd8npek18k6be8ba3oc68.apps.googleusercontent.com");
                CLIENT_SECRET = Config.s("youtube.oauthClientSecret", "SboVhoG9s0rNafixCSGGKXAT");
                DEVICE_CODE_URL = Config.s("youtube.deviceCodeUrl", "https://www.youtube.com/o/oauth2/device/code");
                TOKEN_URL = Config.s("youtube.tokenUrl", "https://www.youtube.com/o/oauth2/token");
                SCOPE = Config.s("youtube.oauthScope", "http://gdata.youtube.com https://www.googleapis.com/auth/youtube-paid-content");
                WEB_VERSION = Config.s("youtube.webClientVersion", "2.20261015.00.00");
                CHAPTER_CAPTURE = Config.set("youtube.chapters.capture", "multiMarkersPlayerBarRenderer", "videoSecondaryInfoRenderer");
                CHAPTER_KEYS = Config.list("youtube.chapters.markerKeys", "DESCRIPTION_CHAPTERS", "AUTO_CHAPTERS");
                CAPTURE = Config.set("youtube.capture", "shelfRenderer", "nextContinuationData");
                // ads (the only thing removed from the answers) and keys a tile does not need
                SKIP = Config.set("youtube.skip", "adSlotRenderer", "inFeedAdLayoutRenderer", "promotedSparklesWebRenderer",
                        "adSlotMetadata", "menu", "trackingParams", "clickTrackingParams", "loggingDirectives",
                        "loggingContext", "onLongPress", "onLongPressCommand", "accessibility", "accessibilityData",
                        "accessibilityContext", "commandMetadata", "onFocusCommand", "reelPlayerOverlayRenderer",
                        "itemPlayback", "watchEndpointSupportedOnesieConfig", "frameworkUpdates", "responseContext",
                        "topbar", "engagementPanels", "playerOverlays");
                // read whatever the bundled config says: the long-feed grids, the signed-in section tabs
                // (Subscriptions' channels, Library's lists), row continuations and the visitor id they need
                Set<String> cap = new HashSet<>(CAPTURE);
                cap.addAll(Arrays.asList("gridRenderer", "tvSecondaryNavRenderer", "horizontalListContinuation",
                        "gridContinuation", "responseContext"));
                CAPTURE = cap;
                Set<String> sk = new HashSet<>(SKIP);
                sk.remove("responseContext");
                SKIP = sk;
                Set<String> sm = new HashSet<>(sk);
                sm.removeAll(Arrays.asList("menu", "onLongPress", "onLongPressCommand"));
                SKIP_MENU = sm;
                HIDE_LABELS = Config.list("youtube.hideChannel.labels", "don't recommend channel");
            }
        });
    }

    YouTubeSource(Context c) {
        super(c, "youtube");
    }

    /** Videos and live streams preview through the iOS client's clear HLS stream (no ads, no DRM). */
    @Override
    public boolean previewVideo(Item item) {
        return item.kind == Item.LIVE || item.kind == Item.VIDEO || isMovie(item);
    }

    /** A YouTube Movies tile: browseId "MV" + the movie's own video id. */
    private static boolean isMovie(Item item) {
        return item.kind == Item.PAGE && item.id.matches("MV[A-Za-z0-9_-]{11}");
    }

    @Override
    public Playback previewPlayback(Item item) throws IOException {
        Playback p = new Playback();
        p.title = item.title;
        p.subtitle = item.subtitle;
        Item v = isMovie(item) ? new Item(Item.VIDEO, item.id.substring(2), item.title, item.subtitle, item.image,
                item.badge, "") : item;
        // a video that just had no clear stream goes straight to the embed player on the next hover (each check is
        // one or two player calls to YouTube)
        if (noClearStream(v.id)) {
            Log.i(TAG, "preview " + v.id + ": no clear stream (remembered)");
            return p;
        }
        iosHls(v, p);
        // on-demand videos: the iOS client often answers without HLS on home connections; the VR client's muxed
        // 360p MP4 (itag 18: plain H.264/AAC, no ads, no DRM) is plenty for a muted preview
        if (p.hls == null && v.kind == Item.VIDEO && System.currentTimeMillis() >= vrRefusedUntil) {
            // (YouTube may answer LOGIN_REQUIRED here on some home connections; the account's TV sign-in is not
            // accepted by this client, so the preview then falls back to the muted embed player)
            String mp4 = vrProgressive(v.id, false);
            if (mp4 != null) {
                p.hls = mp4;
                p.userAgent = VR_UA;
                p.live = false;
            }
        }
        if (p.hls == null) rememberNoClearStream(v.id);
        Log.i(TAG, "preview " + v.id + ": " + (p.hls == null ? "no clear stream (artwork)" : p.hls.contains(".m3u8") || p.hls.contains("manifest") ? "HLS" : "MP4"));
        return p;
    }

    /** Muted embed player for the preview box: the same embed ClearTV plays videos in, ad-blocked the same way. */
    @Override
    public String previewWebPage(Item item) {
        String id = isMovie(item) ? item.id.substring(2) : item.kind == Item.VIDEO ? item.id : null;
        if (id == null || !id.matches("[A-Za-z0-9_-]{11}")) return null;
        return "<!doctype html><html><head><meta name=\"referrer\" content=\"strict-origin-when-cross-origin\">"
                + "<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}iframe{position:fixed;left:0;top:0;width:100%;height:100%;border:0}</style>"
                + "</head><body><iframe allow=\"autoplay; encrypted-media\" referrerpolicy=\"strict-origin-when-cross-origin\" src=\"https://www.youtube.com/embed/"
                + id + "?autoplay=1&mute=1&controls=0&disablekb=1&rel=0&fs=0&playsinline=1&iv_load_policy=3&cc_load_policy=0&modestbranding=1&vq=small"
                + "&origin=https%3A%2F%2Fcom.goomero.cleartv\"></iframe></body></html>";
    }

    private static final long NO_STREAM_MS = 10 * 60_000;
    /** Until when the VR client is skipped: it answered LOGIN_REQUIRED, which it then does for every video. */
    private static volatile long vrRefusedUntil;
    /** Video ids that had no clear stream lately, oldest first, with the time they were checked. */
    private static final Map<String, Long> NO_STREAM = new java.util.LinkedHashMap<String, Long>(64, 0.75f, false) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Long> e) {
            return size() > 200;
        }
    };

    private static boolean noClearStream(String id) {
        synchronized (NO_STREAM) {
            Long t = NO_STREAM.get(id);
            if (t == null) return false;
            if (System.currentTimeMillis() - t < NO_STREAM_MS) return true;
            NO_STREAM.remove(id);
            return false;
        }
    }

    private static void rememberNoClearStream(String id) {
        synchronized (NO_STREAM) {
            NO_STREAM.put(id, System.currentTimeMillis());
        }
    }

    private static final String VR_UA = "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip";

    /** The VR client's muxed progressive MP4 (itag 18) for a video, or null. */
    private String vrProgressive(String id, boolean auth) {
        try {
            JSONObject client = new JSONObject().put("clientName", "ANDROID_VR").put("clientVersion", "1.62.27")
                    .put("androidSdkVersion", 32).put("hl", "en").put("gl", "US");
            JSONObject body = new JSONObject().put("videoId", id).put("contentCheckOk", true).put("racyCheckOk", true)
                    .put("context", new JSONObject().put("client", client));
            Map<String, String> h = new HashMap<>();
            h.put("User-Agent", VR_UA);
            h.put("X-Youtube-Client-Name", "28");
            h.put("X-Youtube-Client-Version", "1.62.27");
            String token = auth ? accessToken() : null;
            if (auth && token == null) return null;
            if (token != null) h.put("Authorization", "Bearer " + token);
            JSONObject o = new JSONObject(Http.postJson(API + "player?prettyPrint=false", h, body.toString()));
            JSONArray f = JsonScan.path(o, "streamingData") == null ? null : o.optJSONObject("streamingData").optJSONArray("formats");
            if (f != null) for (int i = 0; i < f.length(); i++) {
                JSONObject x = f.optJSONObject(i);
                if (x != null && !x.optString("url").isEmpty()) return x.optString("url");
            }
            String status = JsonScan.path(o, "playabilityStatus") == null ? "?" : o.optJSONObject("playabilityStatus").optString("status");
            if (!auth && "LOGIN_REQUIRED".equals(status)) vrRefusedUntil = System.currentTimeMillis() + NO_STREAM_MS;
            Log.i(TAG, "preview " + id + ": VR client" + (auth ? " (account) " : " ") + status);
        } catch (IOException | JSONException e) {
            Log.w(TAG, "preview " + id + ": " + e.getMessage());
        }
        return null;
    }

    @Override public String id() { return "youtube"; }
    @Override public String name() { return "YouTube"; }
    @Override public int accent() { return 0xFFFF0033; }
    @Override public int accent2() { return 0xFFCC0000; }
    @Override public String iconKey() { return "www.youtube.com"; }

    @Override
    public List<Nav> navs() {
        List<Nav> l = new ArrayList<>();
        l.add(new Nav("FEtopics", "Home"));
        l.add(new Nav(SHORTS, "Shorts"));
        l.add(new Nav("FEsubscriptions", "Subscriptions"));
        l.add(new Nav("FElibrary", "Library"));
        l.add(new Nav("FEtopics_movies", "Movies & TV"));
        l.add(new Nav("FEstorefront|ogUCKAY%3D", "Free with ads"));
        l.add(new Nav("FEtopics_live", "Live"));
        l.add(new Nav("FEtopics_music", "Music"));
        l.add(new Nav("FEtopics_gaming", "Gaming"));
        l.add(new Nav("FEtopics_news", "News"));
        l.add(new Nav("FEtopics_sports", "Sports"));
        l.add(new Nav("FEtopics_podcasts", "Podcasts"));
        return l;
    }

    // ------------------------------------------------------------------------------------- browse

    @Override
    public Item.Page load(Nav nav) throws IOException {
        boolean personal = nav.id.equals("FEsubscriptions") || nav.id.equals("FElibrary");
        if (personal && !signedIn()) {
            Item.Page p = new Item.Page();
            p.empty = "Sign in to see your " + (nav.id.equals("FElibrary") ? "history, playlists and Watch later." : "subscriptions.");
            return p;
        }
        if (nav.id.equals(SHORTS)) return shorts("CA8=");
        String[] parts = nav.id.split("\\|", 2);
        Item.Page p = browse(parts[0], parts.length > 1 ? parts[1] : null);
        // YouTube's own Home is empty while signed out (it only offers a search box); show the top rows of each
        // topic instead, the closest thing to the TV app's signed-out start page. Which topic leads rotates, so
        // the signed-out home is not the same stitch every visit.
        if (nav.id.equals("FEtopics") && p.isEmpty()) p = topicsHome(prefs.getInt("home_visit", 0));
        if (nav.id.equals("FEtopics_movies") && p.isEmpty()) p = moviesFallback();
        // Home, signed in or out: videos already shown move back, and a fresh-search row brings newer channels.
        if (nav.id.equals("FEtopics")) p = refreshHome(p);
        return p;
    }

    /**
     * Movies & TV never ends on an empty page: when the topic answers without rows (a signed-in account, region or
     * a new answer shape), try it signed out, then YouTube's Movies storefront, the YouTube Movies channel and
     * finally a search for free full movies.
     */
    private Item.Page moviesFallback() {
        Object[][] tries = {
                {"browse", "FEtopics_movies", Boolean.FALSE},
                {"browse", "FEstorefront", Boolean.TRUE},
                {"browse", "FEstorefront", Boolean.FALSE},
                {"browse", "UCuVPpxrm2VAgpH3Ktln4HXg", Boolean.FALSE},
                {"search", "free full movies", Boolean.FALSE}};
        for (Object[] t : tries) {
            boolean auth = (Boolean) t[2];
            if (auth && !signedIn()) continue;
            if (!auth && t[1].equals("FEtopics_movies") && !signedIn()) continue;
            try {
                JSONObject extra = new JSONObject().put(t[0].equals("search") ? "query" : "browseId", t[1]);
                Item.Page p = shelves((String) t[0], extra, auth);
                Log.i(TAG, "Movies & TV fallback " + t[1] + (auth ? " (account)" : " (signed out)") + ": "
                        + p.shelves.size() + " rows");
                if (!p.isEmpty()) return p;
            } catch (IOException | JSONException e) {
                Log.w(TAG, "Movies & TV fallback " + t[1] + ": " + e.getMessage());
            }
        }
        Item.Page p = new Item.Page();
        p.empty = "YouTube didn't send any movies right now. Try again in a moment.";
        return p;
    }

    private Item.Page topicsHome(int shift) throws IOException {
        final String[] base = {"FEtopics_music", "FEtopics_live", "FEtopics_gaming", "FEtopics_news",
                "FEtopics_sports", "FEtopics_movies", "FEtopics_podcasts"};
        final String[] topics = new String[base.length];
        int start = Math.floorMod(shift, base.length);
        for (int i = 0; i < base.length; i++) topics[i] = base[(start + i) % base.length];
        java.util.concurrent.ExecutorService pool = java.util.concurrent.Executors.newFixedThreadPool(3);
        try {
            List<java.util.concurrent.Future<Item.Page>> parts = new ArrayList<>();
            for (final String t : topics) {
                parts.add(pool.submit(new java.util.concurrent.Callable<Item.Page>() {
                    @Override
                    public Item.Page call() throws IOException {
                        return browse(t, null);
                    }
                }));
            }
            Item.Page out = new Item.Page();
            IOException last = null;
            for (int round = 0; round < 3; round++) {
                for (java.util.concurrent.Future<Item.Page> f : parts) {
                    try {
                        Item.Page p = f.get();
                        int seen = 0;
                        for (Item.Shelf s : p.shelves) {
                            if (s.items.isEmpty()) continue;
                            if (seen++ == round) {
                                out.shelves.add(s);
                                break;
                            }
                        }
                    } catch (java.util.concurrent.ExecutionException e) {
                        if (e.getCause() instanceof IOException) last = (IOException) e.getCause();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        throw new IOException("interrupted");
                    }
                }
            }
            if (out.isEmpty() && last != null) throw last;
            if (out.isEmpty()) out.empty = "Nothing here yet.";
            return out;
        } finally {
            pool.shutdownNow();
        }
    }

    /**
     * Home was the same rows every visit: signed out, YouTube's home is only a sign-in box, so the topic shelves
     * were stitched in a fixed order; signed in, it is one browse and playback in the embed player never tells
     * YouTube what was watched, so its recommended shelf stays put. Videos already shown move to the back (and a
     * shelf that was entirely shown rotates), a couple of rows that were already seen load their next page, and a
     * search limited to this month's uploads adds newer videos from smaller channels.
     */
    private Item.Page refreshHome(Item.Page p) {
        if (p == null || p.isEmpty()) return p;
        long t0 = android.os.SystemClock.uptimeMillis();
        int visit = prefs.getInt("home_visit", 0);
        Set<String> seen = new HashSet<>(readSeen());
        int continued = deepen(p, seen, t0);
        int demoted = 0;
        for (Item.Shelf s : p.shelves) demoted += Fresh.demote(s.items, seen, visit);
        List<Item> personal = personalSeeds();
        List<Item> seeds = Fresh.pickSeeds(personal, pageVideos(p, seen), visit, Config.i("youtube.home.seeds", 2));
        int added = 0;
        try {
            added = discoverInto(p, seeds, personal.isEmpty(), seen);
        } catch (IOException e) {
            Log.w(TAG, "home fresh: " + e.getMessage());
        }
        rememberSeen(p, visit);
        Log.i(TAG, "home fresh: visit " + visit + ", continued " + continued + ", demoted " + demoted
                + ", seeds " + seeds.size() + (personal.isEmpty() ? " from the page" : " from watched")
                + ", new " + added + " in " + (android.os.SystemClock.uptimeMillis() - t0) + " ms");
        return p;
    }

    /** The next page of a shelf whose front was already shown, so the following visit is not those same tiles. */
    private int deepen(Item.Page p, Set<String> seen, long t0) {
        int n = 0, max = Config.i("youtube.home.continuations", 2);
        long until = t0 + Config.i("youtube.home.continuationMs", 2000);
        for (Item.Shelf s : new ArrayList<>(p.shelves)) {
            if (n >= max || android.os.SystemClock.uptimeMillis() > until) break;
            if (s.more == null || s.items.size() < 4) continue;
            int front = Math.min(8, s.items.size()), known = 0;
            for (int i = 0; i < front; i++) if (seen.contains(s.items.get(i).id)) known++;
            if (known * 2 < front) continue;
            try {
                Item.Shelf more = moreRow(s.more);
                if (more == null || more.items.isEmpty()) continue;
                Set<String> ids = new HashSet<>();
                for (Item it : s.items) ids.add(it.id);
                int before = s.items.size();
                for (Item it : more.items) if (ids.add(it.id)) s.items.add(it);
                if (more.more != null) s.more = more.more;
                if (s.items.size() > before) n++;
            } catch (IOException e) {
                Log.w(TAG, "home fresh: a continuation failed");
            }
        }
        return n;
    }

    /** Videos on the page that can seed a search: ones not shown yet first, one per channel. */
    private List<Item> pageVideos(Item.Page p, Set<String> seen) {
        List<Item> fresh = new ArrayList<>(), old = new ArrayList<>();
        Set<String> chans = new HashSet<>();
        for (Item.Shelf s : p.shelves) for (Item it : s.items) {
            if (fresh.size() + old.size() >= 16) return join(fresh, old);
            if (!videoId(it) || !it.commerce.isEmpty()) continue;
            String ch = it.channel != null && it.channel.id.startsWith("UC") ? it.channel.id : channelName(it.subtitle);
            if (!ch.isEmpty() && !chans.add(ch)) continue;
            (seen.contains(it.id) ? old : fresh).add(it);
        }
        return join(fresh, old);
    }

    private static List<Item> join(List<Item> a, List<Item> b) {
        List<Item> out = new ArrayList<>(a);
        out.addAll(b);
        return out;
    }

    private static boolean videoId(Item it) {
        return it != null && (it.kind == Item.VIDEO || it.kind == Item.LIVE) && it.id.matches("[A-Za-z0-9_-]{11}");
    }

    /**
     * One row of newer videos (and, when there are a few, their channels), from a this-month search for each seed.
     * Seeds are recent watches when there are any, otherwise videos already on the home. Returns how many videos
     * were added.
     */
    private int discoverInto(Item.Page p, final List<Item> seeds, boolean fromPage, Set<String> seen) throws IOException {
        if (seeds.isEmpty()) return 0;
        final long until = android.os.SystemClock.uptimeMillis() + Config.i("youtube.home.freshMs", 2800);
        java.util.concurrent.ExecutorService pool = java.util.concurrent.Executors.newFixedThreadPool(Math.max(1, seeds.size()));
        try {
            List<java.util.concurrent.Future<Found>> jobs = new ArrayList<>();
            for (final Item seed : seeds) {
                jobs.add(pool.submit(new java.util.concurrent.Callable<Found>() {
                    @Override
                    public Found call() throws IOException {
                        return findFresh(seed);
                    }
                }));
            }
            List<Found> found = new ArrayList<>();
            for (java.util.concurrent.Future<Found> f : jobs) {
                try {
                    Found one = await(f, until);
                    if (one != null && !one.items.isEmpty()) found.add(one);
                } catch (IOException e) {
                    Log.w(TAG, "home fresh: a search failed");
                }
            }
            if (found.isEmpty()) return 0;
            Set<String> onPage = new HashSet<>();
            for (Item.Shelf s : p.shelves) for (Item it : s.items) onPage.add(it.id);
            for (Item seed : seeds) onPage.add(seed.id);
            List<HiddenChannels.Entry> hidden = HiddenChannels.of(app, id());
            List<List<Item>> cols = new ArrayList<>();
            for (Found f : found) cols.add(rankFresh(f, onPage, seen, hidden));
            int max = Config.i("youtube.home.channels", 12);
            List<Item> lead = new ArrayList<>();
            Set<String> ids = new HashSet<>(), chans = new HashSet<>();
            for (int round = 0; lead.size() < max; round++) {
                boolean any = false;
                for (List<Item> col : cols) {
                    if (round >= col.size()) continue;
                    any = true;
                    Item x = col.get(round);
                    String ch = x.channel != null && x.channel.id.startsWith("UC") ? x.channel.id : channelName(x.subtitle);
                    if (!ids.add(x.id) || (!ch.isEmpty() && !chans.add(ch))) continue;
                    if (lead.size() < max) lead.add(x);
                }
                if (!any) break;
            }
            if (lead.isEmpty()) return 0;
            List<Item> tiles = new ArrayList<>();
            for (Item x : lead) {
                if (x.channel == null || !x.channel.id.startsWith("UC") || tiles.size() >= max) continue;
                String name = x.channel.title.equals("Channel") ? channelName(x.subtitle) : x.channel.title;
                Item c = new Item(Item.CHANNEL, x.channel.id, name.isEmpty() ? "Channel" : name, "Channel",
                        x.channel.image, "", "");
                tiles.add(c);
            }
            int inserted = 0;
            if (tiles.size() >= 2) {
                Item.Shelf cs = new Item.Shelf(fromPage ? "Channels to try" : "Channels for you", tiles);
                cs.mixed = true;
                p.shelves.add(0, cs);
                inserted++;
            }
            Item.Shelf vs = new Item.Shelf(fromPage ? "New channels" : "New for you", lead);
            vs.mixed = true;
            p.shelves.add(0, vs);
            inserted++;
            p.empty = "";
            if (p.grid >= 0) p.grid += inserted;
            return lead.size();
        } finally {
            pool.shutdownNow();
        }
    }

    /** A this-month search for what {@code seed} is about, plus the descriptor that ranks the results. */
    private Found findFresh(Item seed) throws IOException {
        Descriptor.Source meta = new Descriptor.Source();
        meta.title = seed.title == null ? "" : seed.title;
        if (seed.channel != null) meta.owner = seed.channel.title;
        try {
            Descriptor.Source got = webMeta(seed.id);
            if (!got.title.isEmpty() || !got.keywords.isEmpty() || !got.description.isEmpty()) {
                if (got.title.isEmpty()) got.title = meta.title;
                if (got.owner.isEmpty()) got.owner = meta.owner;
                meta = got;
            }
        } catch (IOException e) {
            Log.w(TAG, "home fresh: no metadata");
        }
        Descriptor d = new Descriptor(meta, descriptorWeights());
        List<String> qs = d.isEmpty() ? new ArrayList<String>() : d.queries(1, null);
        String q = qs.isEmpty() ? meta.title.trim() : qs.get(0);
        if (q.length() > 80) q = q.substring(0, 80);
        if (q.length() < 3) return null;
        Found f = new Found();
        f.descriptor = d.isEmpty() ? null : d;
        f.snippets = new HashMap<>();
        String params = Config.s("youtube.home.freshParams", "EgQIBBAB");
        f.items = webSearch(q, f.snippets, params);
        // a narrow phrase sometimes has nothing from this month; the title still names the subject
        if (f.items.isEmpty() && !q.equalsIgnoreCase(meta.title.trim()) && meta.title.trim().length() >= 3) {
            String t = meta.title.trim();
            if (t.length() > 80) t = t.substring(0, 80);
            f.items = webSearch(t, f.snippets, params);
        }
        f.srcId = seed.channel != null && seed.channel.id.startsWith("UC") ? seed.channel.id : "";
        f.srcName = seed.channel != null && !seed.channel.title.equals("Channel") ? seed.channel.title : channelName(seed.subtitle);
        return f;
    }

    /** One seed's results, best match and newest modest channels first. Unseen videos lead; seen ones only fill in. */
    private List<Item> rankFresh(Found f, Set<String> block, Set<String> seen, List<HiddenChannels.Entry> hidden) {
        final String srcId = f.srcId, srcName = f.srcName == null ? "" : f.srcName;
        Similar sim = new Similar(new Similar.Key() {
            @Override
            public String of(Item x) {
                if (!videoId(x) || block.contains(x.id)) return null;
                if (!srcId.isEmpty() && x.channel != null && srcId.equals(x.channel.id)) return null;
                String n = x.channel != null && !x.channel.title.equals("Channel") ? x.channel.title : channelName(x.subtitle);
                if (!srcName.isEmpty() && n.equalsIgnoreCase(srcName)) return null;
                if (n.isEmpty() || n.matches("(?i).*\\d.*\\b(views?|watching|ago)\\b.*")) return null;
                String[] key = channelKey(x);
                if (key != null && HiddenChannels.contains(hidden, id(), key)) return null;
                return n.toLowerCase(java.util.Locale.ROOT).trim();
            }
        });
        sim.add(f.items, 1);
        List<Similar.Group> groups = sim.ranked();
        Fresh.Tune tune = homeTune();
        if (f.descriptor != null) {
            groups = sim.ranked(f.descriptor.fit(groups, f.snippets, null, descriptorWeights()),
                    Config.d("youtube.similar.descriptor.fitWeight", 2), Config.d("youtube.similar.descriptor.miss", 0.6));
            tune.haveMatch = true;
        }
        Fresh.tune(groups, null, tune);
        List<Item> unseen = new ArrayList<>(), rest = new ArrayList<>();
        for (Similar.Group g : groups) {
            Item pick = null, fallback = null;
            for (Item x : g.items) {
                if (fallback == null) fallback = x;
                if (!seen.contains(x.id)) {
                    pick = x;
                    break;
                }
            }
            if (pick != null) unseen.add(pick);
            else if (fallback != null) rest.add(fallback);
        }
        if (unseen.size() >= 4) return unseen;
        unseen.addAll(rest);
        return unseen;
    }

    private static final class Found {
        Descriptor descriptor;
        List<Item> items = new ArrayList<>();
        Map<String, String> snippets = new HashMap<>();
        String srcId = "", srcName = "";
    }

    private static Descriptor.Weights descriptorWeights() {
        Descriptor.Weights w = new Descriptor.Weights();
        w.tag = Config.d("youtube.similar.descriptor.tag", w.tag);
        w.hashtag = Config.d("youtube.similar.descriptor.hashtag", w.hashtag);
        w.topic = Config.d("youtube.similar.descriptor.topic", w.topic);
        w.title = Config.d("youtube.similar.descriptor.title", w.title);
        w.chapter = Config.d("youtube.similar.descriptor.chapter", w.chapter);
        w.description = Config.d("youtube.similar.descriptor.description", w.description);
        w.category = Config.d("youtube.similar.descriptor.category", w.category);
        w.phrase = Config.d("youtube.similar.descriptor.phrase", w.phrase);
        w.idfFloor = Config.d("youtube.similar.descriptor.idfFloor", w.idfFloor);
        w.searchFit = Config.d("youtube.similar.descriptor.searchFit", w.searchFit);
        w.terms = Config.i("youtube.similar.descriptor.terms", w.terms);
        return w;
    }

    private static Fresh.Tune homeTune() {
        Fresh.Tune t = new Fresh.Tune();
        t.boost = Config.d("youtube.similar.freshBoost", t.boost);
        t.penalty = Config.d("youtube.similar.repeatPenalty", t.penalty);
        t.minMatch = Config.d("youtube.similar.freshMinMatch", t.minMatch);
        t.recentDays = Config.d("youtube.similar.recentDays", t.recentDays);
        t.monthDays = Config.d("youtube.similar.monthDays", t.monthDays);
        t.modestViews = Config.i("youtube.similar.modestViews", (int) t.modestViews);
        t.midViews = Config.i("youtube.similar.midViews", (int) t.midViews);
        t.megaViews = Config.i("youtube.similar.megaViews", (int) t.megaViews);
        return t;
    }

    private List<String> readSeen() {
        List<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs.getString("home_seen", "[]"));
            for (int i = 0; i < a.length(); i++) {
                String id = a.optString(i, "");
                if (!id.isEmpty()) out.add(id);
            }
        } catch (JSONException ignored) {
            // a damaged list just starts over
        }
        return out;
    }

    /** The ids now at the front of Home count as shown, so the next visit leads with different ones. */
    private void rememberSeen(Item.Page p, int visit) {
        List<String> ids = readSeen();
        Set<String> have = new HashSet<>(ids);
        int shelves = 0;
        for (Item.Shelf s : p.shelves) {
            if (shelves++ >= 6) break;
            int n = 0;
            for (Item it : s.items) {
                if (n++ >= 8) break;
                if (videoId(it) && have.add(it.id)) ids.add(it.id);
            }
        }
        int max = Config.i("youtube.home.seen", 240);
        if (ids.size() > max) ids = new ArrayList<>(ids.subList(ids.size() - max, ids.size()));
        JSONArray a = new JSONArray();
        for (String id : ids) a.put(id);
        prefs.edit().putString("home_seen", a.toString()).putInt("home_visit", visit + 1).apply();
    }

    /** Watches in ClearTV (including ones finished, which leave Continue watching), then the account's history. */
    private List<Item> personalSeeds() {
        java.util.LinkedHashMap<String, Item> map = new java.util.LinkedHashMap<>();
        for (Item it : recentWatches()) putVideo(map, it);
        for (Library.Entry e : Library.continueWatching(app)) {
            if ("youtube".equals(e.service)) putVideo(map, e.item);
        }
        for (Item it : Library.history(app, "youtube")) putVideo(map, it);
        return new ArrayList<>(map.values());
    }

    private static void putVideo(java.util.LinkedHashMap<String, Item> map, Item it) {
        if (!videoId(it) || map.containsKey(it.id)) return;
        map.put(it.id, it);
    }

    private List<Item> recentWatches() {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs.getString("recent", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                Item it = new Item(Item.VIDEO, o.optString("i"), o.optString("t"), o.optString("s"), o.optString("img"), "", "");
                if (!o.optString("c").isEmpty()) {
                    it.channel = new Item(Item.CHANNEL, o.optString("c"), o.optString("cn", "Channel"), "Channel",
                            o.optString("ci"), "", "");
                }
                if (videoId(it)) out.add(it);
            }
        } catch (JSONException ignored) {
            // start again next time
        }
        return out;
    }

    private void rememberWatch(Item it) {
        try {
            JSONArray a = new JSONArray(prefs.getString("recent", "[]"));
            JSONObject first = a.optJSONObject(0);
            if (first != null && it.id.equals(first.optString("i"))) return;
            JSONArray next = new JSONArray();
            next.put(new JSONObject().put("i", it.id).put("t", it.title).put("s", it.subtitle).put("img", it.image)
                    .put("c", it.channel != null && it.channel.id.startsWith("UC") ? it.channel.id : "")
                    .put("cn", it.channel != null ? it.channel.title : "")
                    .put("ci", it.channel != null ? it.channel.image : ""));
            for (int i = 0; i < a.length() && next.length() < 12; i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null || it.id.equals(o.optString("i"))) continue;
                next.put(o);
            }
            prefs.edit().putString("recent", next.toString()).apply();
        } catch (JSONException e) {
            Log.w(TAG, "recent watch: " + e.getMessage());
        }
    }

    /** Channel keys that led the last More like this for this video (so the next one leads with others). */
    private Set<String> readLeads(String videoId) {
        Set<String> out = new HashSet<>();
        try {
            JSONArray a = new JSONArray(prefs.getString("ml", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null || !videoId.equals(o.optString("i"))) continue;
                JSONArray ks = o.optJSONArray("k");
                if (ks == null) continue;
                for (int j = 0; j < ks.length(); j++) out.add(ks.optString(j));
            }
        } catch (JSONException ignored) {
            // no previous leads
        }
        return out;
    }

    private void saveLeads(String videoId, List<String> keys) {
        if (videoId == null || keys == null || keys.isEmpty()) return;
        try {
            JSONArray a = new JSONArray(prefs.getString("ml", "[]"));
            JSONArray ks = new JSONArray();
            for (int i = 0; i < keys.size() && i < 8; i++) ks.put(keys.get(i));
            JSONArray next = new JSONArray();
            next.put(new JSONObject().put("i", videoId).put("k", ks));
            for (int i = 0; i < a.length() && next.length() < 40; i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null || videoId.equals(o.optString("i"))) continue;
                next.put(o);
            }
            prefs.edit().putString("ml", next.toString()).apply();
        } catch (JSONException e) {
            Log.w(TAG, "more like leads: " + e.getMessage());
        }
    }

    private Item.Page browse(String browseId, String params) throws IOException {
        JSONObject extra = new JSONObject();
        try {
            extra.put("browseId", browseId);
            if (params != null && !params.isEmpty()) extra.put("params", java.net.URLDecoder.decode(params, "UTF-8"));
        } catch (JSONException e) {
            throw new IOException(e);
        }
        return shelves("browse", extra);
    }

    /**
     * The next part of a page: the next shelves, or the next tiles of a long grid (history, a channel list),
     * or the next Shorts. The token carries the visitor id of the answer it came from: YouTube only continues
     * a signed-out feed for the same visitor.
     */
    @Override
    public Item.Page more(String token) throws IOException {
        if (token.startsWith(SHORTS + ":")) return shorts(token.substring(SHORTS.length() + 1));
        return shelves("browse", continuation(token));
    }

    /** The next tiles of a row (YouTube's horizontal list continuation). */
    @Override
    public Item.Shelf moreRow(String token) throws IOException {
        Item.Page p = shelves("browse", continuation(token));
        if (p.shelves.isEmpty()) return null;
        Item.Shelf s = p.shelves.get(0);
        return s.items.isEmpty() ? null : s;
    }

    private static JSONObject continuation(String token) throws IOException {
        String[] t = token.split("\n", 2);
        JSONObject extra = new JSONObject();
        try {
            extra.put("continuation", t[0]);
            if (t.length > 1 && !t[1].isEmpty()) extra.put(VISITOR, t[1]);
        } catch (JSONException e) {
            throw new IOException(e);
        }
        return extra;
    }

    /** Key (in a request being built) for the visitor id; tvContext moves it into the client context. */
    private static final String VISITOR = "_visitor";

    /**
     * Shorts, as the TV app's Shorts tab plays them: YouTube's Shorts sequence (video ids, ~10 a page), with
     * each title from YouTube's public oEmbed. Shown as a grid that keeps loading as you scroll down.
     */
    private Item.Page shorts(String params) throws IOException {
        List<String> ids = new ArrayList<>();
        String next = params;
        for (int page = 0; page < 2 && next != null; page++) {
            JSONObject extra = new JSONObject();
            try {
                extra.put("sequenceParams", next);
            } catch (JSONException e) {
                throw new IOException(e);
            }
            String body;
            try (Http.Response r = call("reel/reel_watch_sequence", tvContext(extra), true)) {
                body = new String(Http.readAll(r.body, 2 << 20), StandardCharsets.UTF_8);
            }
            next = null;
            try {
                JSONObject o = new JSONObject(body);
                JSONArray e = o.optJSONArray("entries");
                if (e != null) for (int i = 0; i < e.length(); i++) {
                    JSONObject w = JsonScan.path(e.optJSONObject(i), "command", "reelWatchEndpoint");
                    String id = w == null ? "" : w.optString("videoId");
                    if (!id.isEmpty() && !ids.contains(id)) ids.add(id);
                }
                String c = o.optString("continuation", "");
                if (!c.isEmpty()) next = java.net.URLDecoder.decode(c, "UTF-8");
            } catch (JSONException e) {
                throw new IOException("YouTube sent unreadable Shorts");
            }
        }
        final List<Item> items = new ArrayList<>();
        final String[] titles = new String[ids.size()], authors = new String[ids.size()];
        java.util.concurrent.ExecutorService pool = java.util.concurrent.Executors.newFixedThreadPool(4);
        try {
            List<java.util.concurrent.Future<?>> jobs = new ArrayList<>();
            for (int i = 0; i < ids.size(); i++) {
                final int k = i;
                final String id = ids.get(i);
                jobs.add(pool.submit(new Runnable() {
                    @Override
                    public void run() {
                        try (Http.Response r = Http.open("https://www.youtube.com/oembed?format=json&url="
                                + java.net.URLEncoder.encode("https://www.youtube.com/shorts/" + id, "UTF-8"), new HashMap<String, String>(), null, null, true)) {
                            if (r.code != 200) return;
                            JSONObject o = new JSONObject(new String(Http.readAll(r.body, 64 << 10), StandardCharsets.UTF_8));
                            titles[k] = o.optString("title", "");
                            authors[k] = o.optString("author_name", "");
                        } catch (IOException | JSONException ignored) {
                            // no title: the tile is left out rather than shown without one
                        }
                    }
                }));
            }
            for (java.util.concurrent.Future<?> f : jobs) {
                try {
                    f.get(15, java.util.concurrent.TimeUnit.SECONDS);
                } catch (Exception ignored) {
                    // a slow title is skipped
                }
            }
        } finally {
            pool.shutdownNow();
        }
        for (int i = 0; i < ids.size(); i++) {
            if (titles[i] == null || titles[i].isEmpty()) continue;
            Item it = new Item(Item.VIDEO, ids.get(i), titles[i], authors[i] == null ? "" : authors[i],
                    "https://i.ytimg.com/vi/" + ids.get(i) + "/mqdefault.jpg", "Shorts", "");
            items.add(it);
        }
        Item.Page p = new Item.Page();
        p.shelves.add(new Item.Shelf("Shorts", items));
        p.grid = 0;
        p.moreExtendsGrid = true;
        if (next != null) p.more = SHORTS + ":" + next;
        if (items.isEmpty()) p.empty = "No Shorts right now.";
        return p;
    }

    @Override
    public Item.Page search(String query) throws IOException {
        JSONObject extra = new JSONObject();
        try {
            extra.put("query", query);
        } catch (JSONException e) {
            throw new IOException(e);
        }
        return shelves("search", extra);
    }

    /** Every video and live tile has a channel (looked up from the video when the tile did not carry it). */
    @Override
    public boolean hasChannel(Item it) {
        return it.channel != null || ((it.kind == Item.VIDEO || it.kind == Item.LIVE) && it.id.matches("[A-Za-z0-9_-]{11}"));
    }

    /**
     * The uploader's channel: the TV player answer's videoDetails (small), else the owner on the web watch page
     * data ("next", videoOwnerRenderer), which also answers for videos the signed-out TV player refuses
     * (LOGIN_REQUIRED). No sign-in needed for either.
     */
    @Override
    public Item channelOf(Item it) throws IOException {
        if (it.channel != null) return it.channel;
        if (!hasChannel(it)) return null;
        String name = it.subtitle.split(" · ")[0].trim();
        try {
            JSONObject body = new JSONObject().put("videoId", it.id).put("contentCheckOk", true).put("racyCheckOk", true);
            String raw;
            try (Http.Response r = call("player", tvContext(body), false)) {
                raw = new String(Http.readAll(r.body, 1 << 20), StandardCharsets.UTF_8);
            }
            JSONObject vd = new JSONObject(raw).optJSONObject("videoDetails");
            String ch = vd == null ? "" : vd.optString("channelId", "");
            if (ch.startsWith("UC")) {
                String author = vd.optString("author", "");
                return channelTile(ch, author.isEmpty() ? name : author);
            }
            JSONObject client = new JSONObject().put("clientName", "WEB").put("clientVersion", WEB_VERSION).put("hl", "en").put("gl", "US");
            JSONObject nb = new JSONObject().put("videoId", it.id).put("context", new JSONObject().put("client", client));
            Map<String, String> h = new HashMap<>();
            h.put("User-Agent", Http.DESKTOP_UA);
            h.put("Origin", "https://www.youtube.com");
            try (Http.Response r = Http.open(API + "next?prettyPrint=false", h, nb.toString().getBytes(StandardCharsets.UTF_8),
                    "application/json", true)) {
                raw = new String(Http.readAll(r.body, 8 << 20), StandardCharsets.UTF_8);
            }
            JSONObject owner = findKey(new JSONObject(raw), "videoOwnerRenderer", 0);
            JSONObject be = owner == null ? null : JsonScan.path(owner, "navigationEndpoint", "browseEndpoint");
            String title = owner == null ? "" : JsonScan.text(owner.optJSONObject("title"));
            if (owner != null && (be == null || !be.optString("browseId", "").startsWith("UC"))) {
                // a collaboration: the owner opens a picker of the creators instead of a channel; the first is the uploader
                JSONObject first = findKey(owner, "listItemViewModel", 0);
                be = findKey(first != null ? first : owner, "browseEndpoint", 0);
                String t = first == null ? "" : JsonScan.text(first.optJSONObject("title"));
                if (!t.isEmpty()) title = t;
            }
            ch = be == null ? "" : be.optString("browseId", "");
            if (!ch.startsWith("UC")) {
                Log.i(TAG, "no channel for " + it.id);
                return null;
            }
            return channelTile(ch, title.isEmpty() ? name : title);
        } catch (JSONException e) {
            throw new IOException("YouTube sent an unreadable video answer");
        }
    }

    private static volatile String WEB_VERSION;
    /** Where the web watch data keeps the chapters (the player bar markers, the description) and which marker lists count. */
    private static volatile Set<String> CHAPTER_CAPTURE;
    private static volatile String[] CHAPTER_KEYS;

    /** Keys the chapter read never builds (the answer is ~0.5-1 MB; only two small objects are kept). */
    private static final Set<String> CHAPTER_SKIP = new HashSet<>(Arrays.asList("frameworkUpdates", "responseContext",
            "engagementPanels", "trackingParams", "clickTrackingParams", "loggingDirectives", "commandMetadata",
            "accessibility", "accessibilityData", "thumbnail", "thumbnails", "secondaryResults", "menu", "onTap"));

    /**
     * The video's chapters from the web watch data ("next", signed out, the same call as {@link #channelOf}): the
     * player bar's chapter markers (the creator's description chapters first, else YouTube's automatic ones),
     * else a timestamp list in the description. Null for a video without chapters.
     */
    @Override
    public ChapterList chapters(Item it) throws IOException {
        if (it == null || it.kind == Item.LIVE || !it.id.matches("[A-Za-z0-9_-]{11}")) return null;
        final java.util.Map<String, ChapterList> markers = new HashMap<>();
        final String[] desc = {null};
        try {
            JSONObject client = new JSONObject().put("clientName", "WEB").put("clientVersion", WEB_VERSION).put("hl", "en").put("gl", "US");
            JSONObject nb = new JSONObject().put("videoId", it.id).put("context", new JSONObject().put("client", client));
            Map<String, String> h = new HashMap<>();
            h.put("User-Agent", Http.DESKTOP_UA);
            h.put("Origin", "https://www.youtube.com");
            try (Http.Response r = Http.open(API + "next?prettyPrint=false", h, nb.toString().getBytes(StandardCharsets.UTF_8),
                    "application/json", true)) {
                JsonReader jr = new JsonReader(new InputStreamReader(r.body, StandardCharsets.UTF_8));
                JsonScan.scan(jr, CHAPTER_CAPTURE, NONE, CHAPTER_SKIP, new JsonScan.Sink() {
                    @Override
                    public void onValue(String key, String name, JSONObject v) {
                        JSONArray map = v.optJSONArray("markersMap");
                        if (map != null) {
                            for (int i = 0; i < map.length(); i++) {
                                JSONObject e = map.optJSONObject(i);
                                if (e == null) continue;
                                JSONArray chs = JsonScan.path(e, "value") == null ? null : e.optJSONObject("value").optJSONArray("chapters");
                                if (chs == null) continue;
                                List<Long> st = new ArrayList<>();
                                List<String> ti = new ArrayList<>();
                                for (int k = 0; k < chs.length(); k++) {
                                    JSONObject cr = JsonScan.path(chs.optJSONObject(k), "chapterRenderer");
                                    if (cr == null) continue;
                                    st.add(cr.optLong("timeRangeStartMillis", -1));
                                    ti.add(JsonScan.text(cr.optJSONObject("title")));
                                }
                                ChapterList l = ChapterList.of(st, ti);
                                if (l != null) markers.put(e.optString("key", ""), l);
                            }
                        }
                        JSONObject ad = v.optJSONObject("attributedDescription");
                        if (ad != null && desc[0] == null) desc[0] = ad.optString("content", null);
                    }
                });
            }
        } catch (JSONException e) {
            throw new IOException("YouTube sent an unreadable video answer");
        }
        for (String k : CHAPTER_KEYS) if (markers.containsKey(k)) return markers.get(k);
        return ChapterList.fromText(desc[0]);
    }

    // ------------------------------------------------------------------ more like this

    @Override
    public boolean hasSimilar(Item it) {
        return it != null && it.kind == Item.VIDEO && it.id.matches("[A-Za-z0-9_-]{11}");
    }

    @Override
    public Item.Page similar(Item it) throws IOException {
        return similar(it, null);
    }

    /**
     * "More like this" that goes looking for new channels. Three kinds of YouTube's own related lists, fetched in
     * parallel: the TV app's watch-next rows ("next", the account's when signed in), the web watch page's related
     * column (signed out; it names each video's channel) and, as a second round, the related columns of the first
     * few videos from other channels. Channels are ranked by how often and how high they turn up across those lists;
     * the source channel and hidden channels are left out of the new-channel rows. The video's own metadata (tags,
     * hashtags, linked game or topic, title, description, chapters: see {@link Descriptor}) adds a few searches for
     * channels those lists miss and ranks every candidate channel by how well its videos match it, so a small channel
     * on the same topic can beat a big general one. Rows: one video per new channel,
     * the new channels themselves, a short row from the source channel, then more videos from the new channels.
     * The first round's rows go to {@code progress} as soon as they are in.
     */
    @Override
    public Item.Page similar(final Item it, Progress progress) throws IOException {
        final long t0 = android.os.SystemClock.uptimeMillis();
        java.util.concurrent.ExecutorService pool = java.util.concurrent.Executors.newFixedThreadPool(
                Math.max(2, Config.i("youtube.similar.seeds", 4)) + Math.max(0, Config.i("youtube.similar.searches", 2))
                        + Math.max(0, Config.i("youtube.similar.freshSearches", 1)) + 4);
        try {
            java.util.concurrent.Future<List<Item>> tvF = pool.submit(new java.util.concurrent.Callable<List<Item>>() {
                @Override
                public List<Item> call() throws IOException {
                    JSONObject extra;
                    try {
                        extra = new JSONObject().put("videoId", it.id);
                    } catch (JSONException e) {
                        throw new IOException(e);
                    }
                    Item.Page p = shelves("next", extra);
                    List<Item> all = new ArrayList<>();
                    for (Item.Shelf s : p.shelves) for (Item x : s.items) {
                        Item m = movieOf(x);
                        if (m != null) all.add(m);
                        else if (x.kind == Item.VIDEO || x.kind == Item.LIVE) all.add(x);
                    }
                    return all;
                }
            });
            java.util.concurrent.Future<WebRelated> webF = pool.submit(new java.util.concurrent.Callable<WebRelated>() {
                @Override
                public WebRelated call() throws IOException {
                    return webRelated(it.id, false, true);
                }
            });
            // the video's own metadata for the descriptor (the web player answer, ~10 KB, without streams)
            java.util.concurrent.Future<Descriptor.Source> metaF = pool.submit(new java.util.concurrent.Callable<Descriptor.Source>() {
                @Override
                public Descriptor.Source call() throws IOException {
                    return webMeta(it.id);
                }
            });
            long wait = Config.i("youtube.similar.firstMs", 8000);
            IOException err = null;
            List<Item> tv = null;
            WebRelated web = null;
            try {
                tv = await(tvF, t0 + wait);
            } catch (IOException e) {
                err = e;
            }
            try {
                web = await(webF, t0 + wait);
            } catch (IOException e) {
                if (err == null) err = e;
            }
            if (tv == null && web == null) throw err != null ? err : new IOException("YouTube didn't answer.");
            long t1 = android.os.SystemClock.uptimeMillis();
            // the source channel: the web page's owner, else the tile's channel or its second line
            String srcId = web != null ? web.ownerId : "";
            String srcName = web != null ? web.ownerName : "";
            if (srcId.isEmpty() && it.channel != null && it.channel.id.startsWith("UC")) srcId = it.channel.id;
            if (srcName.isEmpty() && it.channel != null && !it.channel.title.equals("Channel")) srcName = it.channel.title;
            if (srcName.isEmpty()) srcName = channelName(it.subtitle);
            final Mix mix = new Mix(it, srcId, srcName, HiddenChannels.of(app, id()), readLeads(it.id));
            if (web != null) mix.add(web.items, 1.0);
            if (tv != null) mix.add(tv, 1.0);
            // the descriptor: the web player's metadata (usually in long before the lists), the web page's linked
            // games and music; a video without it is ranked by the lists alone
            Descriptor.Source meta = null;
            try {
                meta = await(metaF, t1 + Config.i("youtube.similar.metaMs", 400));
            } catch (IOException e) {
                Log.w(TAG, "more like: no metadata: " + e.getMessage());
            }
            long tMeta = android.os.SystemClock.uptimeMillis() - t0;
            if (meta != null) {
                if (meta.title.isEmpty()) meta.title = it.title;
                if (meta.owner.isEmpty()) meta.owner = srcName;
                if (web != null) {
                    meta.topics.addAll(web.games);
                    if ("Music".equals(meta.category)) meta.topics.addAll(web.music);
                }
                mix.describe(new Descriptor(meta, mix.weights));
            }
            // second round: the related columns of the best videos from other channels
            List<String> seeds = mix.seeds(Config.i("youtube.similar.seeds", 4), tv, web == null ? null : web.items);
            List<java.util.concurrent.Future<WebRelated>> hops = new ArrayList<>();
            for (final String v : seeds) hops.add(pool.submit(new java.util.concurrent.Callable<WebRelated>() {
                @Override
                public WebRelated call() throws IOException {
                    return webRelated(v);
                }
            }));
            // searches from the descriptor's strongest phrases, for channels the related lists miss.
            // The same phrases are also searched with YouTube's "This month" filter: that list is recent small
            // channels, which a relevance search barely returns.
            final int nSearch = Config.i("youtube.similar.searches", 2);
            final int nFresh = Config.i("youtube.similar.freshSearches", 1);
            final List<String> queries = mix.queries(Math.max(nSearch, 1));
            final String freshParams = Config.s("youtube.similar.freshParams", "EgQIBBAB");
            final double freshW = Config.i("youtube.similar.freshWeight", 50) / 100.0;
            List<java.util.concurrent.Future<List<Item>>> finds = new ArrayList<>();
            for (int i = 0; i < queries.size() && i < nSearch; i++) {
                final String q = queries.get(i);
                finds.add(pool.submit(new java.util.concurrent.Callable<List<Item>>() {
                    @Override
                    public List<Item> call() throws IOException {
                        return webSearch(q, mix.snippets, null);
                    }
                }));
            }
            List<java.util.concurrent.Future<List<Item>>> freshFinds = new ArrayList<>();
            for (int i = 0; i < queries.size() && i < nFresh; i++) {
                final String q = queries.get(i);
                freshFinds.add(pool.submit(new java.util.concurrent.Callable<List<Item>>() {
                    @Override
                    public List<Item> call() throws IOException {
                        return webSearch(q, mix.snippets, freshParams);
                    }
                }));
            }
            // the first rows, while the second round loads (the page also lists the channels that need a picture)
            if (progress != null) progress.partial(mix.page(false));
            long tFirst = android.os.SystemClock.uptimeMillis() - t0;
            // channel tiles whose channel came without a picture (a TV tile names only the channel): the owner's
            // avatar from the start of that video's web watch data, read only up to the owner
            List<java.util.concurrent.Future<WebRelated>> looks = new ArrayList<>();
            int maxLooks = Config.i("youtube.similar.avatarLookups", 20);
            for (final String v : mix.needAvatar.values()) {
                if (looks.size() >= maxLooks) break;
                looks.add(pool.submit(new java.util.concurrent.Callable<WebRelated>() {
                    @Override
                    public WebRelated call() throws IOException {
                        return webOwner(v);
                    }
                }));
            }
            long until = t1 + Config.i("youtube.similar.secondMs", 5000);
            int got = 0;
            for (java.util.concurrent.Future<WebRelated> f : hops) {
                try {
                    WebRelated h = await(f, until);
                    mix.add(h.items, 0.6);
                    mix.avatar(h.ownerId, h.ownerAvatar);
                    got++;
                } catch (IOException e) {
                    Log.w(TAG, "more like: a second list failed: " + e.getMessage());
                }
            }
            long tHops = android.os.SystemClock.uptimeMillis() - t0;
            int found = 0;
            for (java.util.concurrent.Future<List<Item>> f : finds) {
                try {
                    List<Item> l = await(f, until);
                    mix.addFound(l, Config.i("youtube.similar.searchWeight", 30) / 100.0);
                    found++;
                } catch (IOException e) {
                    Log.w(TAG, "more like: a search failed: " + e.getMessage());
                }
            }
            int freshFound = 0;
            for (java.util.concurrent.Future<List<Item>> f : freshFinds) {
                try {
                    List<Item> l = await(f, until);
                    mix.addFresh(l, freshW);
                    freshFound++;
                } catch (IOException e) {
                    Log.w(TAG, "more like: a fresh search failed: " + e.getMessage());
                }
            }
            long tFinds = android.os.SystemClock.uptimeMillis() - t0;
            int looked = 0;
            for (java.util.concurrent.Future<WebRelated> f : looks) {
                try {
                    WebRelated o = await(f, until);
                    if (!o.ownerAvatar.isEmpty()) looked++;
                    mix.avatar(o.ownerId, o.ownerAvatar);
                } catch (IOException e) {
                    Log.w(TAG, "more like: a channel picture failed: " + e.getMessage());
                }
            }
            long tPage0 = android.os.SystemClock.uptimeMillis();
            Item.Page page = mix.page(true);
            long tPage = android.os.SystemClock.uptimeMillis() - tPage0;
            saveLeads(it.id, mix.leads);
            Log.i(TAG, "more like " + it.id + ": tv " + (tv == null ? "-" : tv.size()) + ", web "
                    + (web == null ? "-" : web.items.size()) + " in " + (t1 - t0) + " ms, first rows at " + tFirst + " ms; " + got + "/" + seeds.size()
                    + " second lists by " + tHops + " ms; " + found + "/" + Math.min(nSearch, queries.size()) + " searches, " + freshFound + "/"
                    + freshFinds.size() + " fresh by " + tFinds + " ms; " + looked + "/" + looks.size()
                    + " pictures looked up; " + mix.summary + " (ranked in " + tPage + " ms) in " + (android.os.SystemClock.uptimeMillis() - t0) + " ms");
            if (mix.descriptor != null) Log.i(TAG, "more like " + it.id + ": descriptor in " + tMeta + " ms: "
                    + mix.descriptor.summary(12) + "; searches " + queries + "; top " + mix.top);
            return page;
        } finally {
            pool.shutdownNow();
        }
    }

    /**
     * The YouTube Movies title-page tile for a film or show among related videos (YouTube's own markers: a
     * paid-content badge on a TV tile, an "MV"/"SC" title page), opening like movie tiles elsewhere; null for videos.
     */
    private static Item movieOf(Item x) {
        if (x == null) return null;
        if (x.kind == Item.PAGE && x.id.matches("(MV|SC)[A-Za-z0-9_-]+")) return x;
        if (x.kind != Item.VIDEO || x.commerce.isEmpty() || !x.id.matches("[A-Za-z0-9_-]{11}")) return null;
        String sub = x.subtitle.isEmpty() ? x.commerce : x.subtitle + " · " + x.commerce;
        Item m = new Item(Item.PAGE, "MV" + x.id, x.title, sub, x.image, x.badge, "");
        m.commerce = x.commerce;
        return m;
    }

    private static <T> T await(java.util.concurrent.Future<T> f, long until) throws IOException {
        try {
            return f.get(Math.max(1, until - android.os.SystemClock.uptimeMillis()), java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch (java.util.concurrent.ExecutionException e) {
            Throwable c = e.getCause();
            if (c instanceof IOException) throw (IOException) c;
            throw new IOException(String.valueOf(c));
        } catch (java.util.concurrent.TimeoutException e) {
            f.cancel(true);
            throw new java.net.SocketTimeoutException("YouTube took too long.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted");
        }
    }

    /** The rows of one "More like this" page, built from the ranked channels. */
    private final class Mix {
        final Item of;
        final String srcId, srcName, srcKey;
        final List<HiddenChannels.Entry> hidden;
        final Similar sim;
        final Descriptor.Weights weights = descriptorWeights();
        final Fresh.Tune tune = homeTune();
        /** Channel keys that led the previous More like this for this video. */
        final Set<String> shown;
        /** Channel keys leading the page just built, saved for the next visit. */
        final List<String> leads = new ArrayList<>();
        /** What the video says it is about (null: not known, the lists alone rank). */
        Descriptor descriptor;
        /** Search snippets by video id (searches only). */
        final Map<String, String> snippets = new java.util.concurrent.ConcurrentHashMap<>();
        /** Channels (group keys) in the related lists, as opposed to found only by a search. */
        final Set<String> related = java.util.Collections.synchronizedSet(new HashSet<String>());
        /** The first new channels of the last page, for the log. */
        String top = "";
        /** Films and shows (see movieOf), kept apart from the channels: by title page, best first. */
        final Map<String, double[]> movieScore = new HashMap<>();
        final Map<String, Item> movies = new java.util.LinkedHashMap<>();
        final Set<String> movieTitles = new HashSet<>();
        /** Channel pictures by channel id, from any list that carried one (the same channel's TV tiles do not). */
        final Map<String, String> avatars = new HashMap<>();
        /** Channel tiles of the last page still without a picture: channel id to one of its videos. */
        final Map<String, String> needAvatar = new java.util.LinkedHashMap<>();
        String summary = "";

        Mix(Item of, String srcId, String srcName, List<HiddenChannels.Entry> hidden, Set<String> shown) {
            this.of = of;
            this.srcId = srcId;
            this.srcName = srcName;
            this.srcKey = srcName.toLowerCase(java.util.Locale.ROOT).trim();
            this.hidden = hidden;
            this.shown = shown == null ? new HashSet<String>() : shown;
            tune.haveMatch = false;
            this.sim = new Similar(new Similar.Key() {
                @Override
                public String of(Item x) {
                    if (x.id.equals(Mix.this.of.id)) return null;
                    String n = x.channel != null && !x.channel.title.equals("Channel") ? x.channel.title : channelName(x.subtitle);
                    if (n.isEmpty() || n.matches("(?i).*\\d.*\\b(views?|watching|ago)\\b.*")) return null;
                    return n.toLowerCase(java.util.Locale.ROOT).trim();
                }
            });
        }

        /** One related list: films and shows to the movie row (scored like channels), the creators' videos to the ranking. */
        void add(List<Item> list, double w) {
            List<Item> videos = new ArrayList<>();
            for (int pos = 0; pos < list.size(); pos++) {
                Item x = list.get(pos);
                Item m = movieOf(x);
                if (m == null) {
                    videos.add(x);
                    if (x.channel != null) avatar(x.channel.id, x.channel.image);
                    continue;
                }
                double[] sc = movieScore.get(m.id);
                if (sc == null) {
                    String t = m.title.toLowerCase(java.util.Locale.ROOT).trim();
                    if (m.id.equals("MV" + of.id) || !movieTitles.add(t)) continue;
                    sc = new double[]{0, movies.size()};
                    movieScore.put(m.id, sc);
                    movies.put(m.id, m);
                }
                sc[0] += w * (pos < 8 ? 1.5 : 1.0);
            }
            sim.add(videos, w);
            for (Item x : videos) {
                String k = sim.keyOf(x);
                if (k != null) related.add(k);
            }
        }

        /** A search's videos: ranked like a related list's, but their channels are found only by searching. */
        void addFound(List<Item> list, double w) {
            sim.add(list, w);
            for (Item x : list) if (x.channel != null) avatar(x.channel.id, x.channel.image);
        }

        /**
         * A "this month" search: recent videos, often from small channels. They keep a full descriptor fit (the
         * upload filter already narrowed them; a miss still scores low) instead of the half fit of a broad search.
         */
        void addFresh(List<Item> list, double w) {
            addFound(list, w);
            for (Item x : list) {
                String k = sim.keyOf(x);
                if (k != null) related.add(k);
            }
        }

        void describe(Descriptor d) {
            if (!d.isEmpty()) descriptor = d;
        }

        /** The descriptor's searches, judged against the candidates found so far (none without a descriptor). */
        List<String> queries(int n) {
            if (descriptor == null || n <= 0) return new ArrayList<>();
            return descriptor.queries(n, descriptor.scorer(sim.ranked(), snippets, weights));
        }

        /** The channels by list score, blended with their fit to the descriptor when there is one, then freshness. */
        List<Similar.Group> ranked() {
            List<Similar.Group> all = sim.ranked();
            if (descriptor != null) {
                all = sim.ranked(descriptor.fit(all, snippets, related, weights),
                        Config.d("youtube.similar.descriptor.fitWeight", 2), Config.d("youtube.similar.descriptor.miss", 0.6));
            }
            tune.haveMatch = descriptor != null;
            Fresh.tune(all, shown, tune);
            return all;
        }

        void avatar(String cid, String url) {
            if (cid != null && cid.startsWith("UC") && url != null && !url.isEmpty() && !avatars.containsKey(cid)) avatars.put(cid, url);
        }

        List<Item> rankedMovies() {
            List<Item> l = new ArrayList<>(movies.values());
            java.util.Collections.sort(l, new java.util.Comparator<Item>() {
                @Override
                public int compare(Item a, Item b) {
                    double[] x = movieScore.get(a.id), y = movieScore.get(b.id);
                    int c = Double.compare(y[0], x[0]);
                    return c != 0 ? c : Double.compare(x[1], y[1]);
                }
            });
            int max = Config.i("youtube.similar.movies", 20);
            return l.size() > max ? new ArrayList<>(l.subList(0, max)) : l;
        }

        /** Whether the channel {id, lower-case name} is the source's (a collaboration naming it counts). */
        boolean isSource(String id, String key) {
            if (!srcId.isEmpty() && srcId.equals(id)) return true;
            if (srcKey.isEmpty()) return false;
            return key.equals(srcKey) || key.startsWith(srcKey + " and ") || key.endsWith(" and " + srcKey)
                    || key.contains(" and " + srcKey + " and ");
        }

        private String idOf(Similar.Group g) {
            for (Item x : g.items) if (x.channel != null && x.channel.id.startsWith("UC")) return x.channel.id;
            return "";
        }

        private boolean isHidden(Similar.Group g, String id) {
            if (hidden.isEmpty()) return false;
            String name = g.items.isEmpty() ? g.key : channelName(g.items.get(0).subtitle);
            return HiddenChannels.contains(hidden, id(), new String[]{id, name});
        }

        /** Videos to ask for their own related lists: the first of each other channel, alternating the two lists. */
        List<String> seeds(int n, List<Item> a, List<Item> b) {
            List<String> out = new ArrayList<>();
            Set<String> chans = new HashSet<>();
            int ia = 0, ib = 0;
            List<Item> la = b != null ? b : new ArrayList<Item>(), lb = a != null ? a : new ArrayList<Item>();
            while (out.size() < n && (ia < la.size() || ib < lb.size())) {
                Item x = (out.size() % 2 == 0 && ia < la.size()) || ib >= lb.size() ? la.get(ia++) : lb.get(ib++);
                String k = sim.keyOf(x);
                if (k == null || x.kind != Item.VIDEO) continue;
                Similar.Group g = sim.group(k);
                if (g == null || isSource(idOf(g), k) || isHidden(g, idOf(g)) || !chans.add(k)) continue;
                out.add(x.id);
            }
            return out;
        }

        Item.Page page(boolean complete) {
            List<Item> lead = new ArrayList<>(), chans = new ArrayList<>(), own = new ArrayList<>(), more = new ArrayList<>();
            List<List<Item>> rest = new ArrayList<>();
            int newChannels = 0;
            needAvatar.clear();
            leads.clear();
            int maxLead = Config.i("youtube.similar.channels", 30), maxOwn = Config.i("youtube.similar.ownVideos", 6);
            StringBuilder topLog = new StringBuilder();
            for (Similar.Group g : ranked()) {
                String cid = idOf(g);
                if (isSource(cid, g.key)) {
                    for (Item x : g.items) if (own.size() < maxOwn) own.add(x);
                    continue;
                }
                if (isHidden(g, cid)) continue;
                if (lead.size() >= maxLead) {
                    rest.add(g.items);
                    continue;
                }
                newChannels++;
                if (leads.size() < 8) leads.add(g.key);
                if (newChannels <= 10) topLog.append(newChannels > 1 ? ", " : "").append(g.key)
                        .append(String.format(java.util.Locale.ROOT, " %.2f/%.2f", g.score, g.match));
                lead.add(g.items.get(0));
                if (g.items.size() > 1) rest.add(g.items.subList(1, g.items.size()));
                if (!cid.isEmpty() && chans.size() < Config.i("youtube.similar.channelTiles", 20)) {
                    Item first = g.items.get(0);
                    String name = first.channel != null && !first.channel.title.equals("Channel") ? first.channel.title
                            : channelName(first.subtitle);
                    Item c = channelTile(cid, name);
                    String img = avatars.containsKey(cid) ? avatars.get(cid) : "";
                    if (img.isEmpty() && first.id.matches("[A-Za-z0-9_-]{11}")) needAvatar.put(cid, first.id);
                    c = new Item(Item.CHANNEL, cid, c.title, "Channel", img, "", "");
                    chans.add(c);
                }
            }
            // more from the new channels: round robin by rank, so no channel takes over
            int maxMore = Config.i("youtube.similar.moreVideos", 40);
            for (int round = 0; more.size() < maxMore; round++) {
                boolean any = false;
                for (List<Item> l : rest) {
                    if (round < l.size()) {
                        any = true;
                        if (more.size() < maxMore) more.add(l.get(round));
                    }
                }
                if (!any) break;
            }
            Item.Page p = new Item.Page();
            String src = srcName.isEmpty() ? "this channel" : srcName;
            if (!lead.isEmpty()) p.shelves.add(new Item.Shelf("New channels like " + src, lead));
            if (chans.size() >= 2) p.shelves.add(new Item.Shelf("Channels like " + src, chans));
            List<Item> films = rankedMovies();
            if (!films.isEmpty()) p.shelves.add(new Item.Shelf("Movies like this", films));
            if (!own.isEmpty()) p.shelves.add(new Item.Shelf("More from " + src, own));
            if (complete && !more.isEmpty()) {
                p.shelves.add(new Item.Shelf("More from these channels", more));
                p.grid = p.shelves.size() - 1;
            }
            if (p.isEmpty()) p.empty = name() + " lists nothing similar for this video.";
            top = topLog.toString();
            summary = newChannels + " new channels, " + chans.size() + " channel tiles, " + own.size() + " from the source, "
                    + more.size() + " more, " + films.size() + " movies";
            return p;
        }
    }

    /** The web watch page's related column for a video and the video's owner. */
    private static final class WebRelated {
        final List<Item> items = new ArrayList<>();
        /** The games the description links (its "Games" cards) and the music it credits (song, artist). */
        final List<String> games = new ArrayList<>(), music = new ArrayList<>();
        String ownerId = "", ownerName = "", ownerAvatar = "";
    }

    /** Ends a watch-data read once the owner is in. */
    private static final class OwnerFound extends RuntimeException {
        @Override
        public synchronized Throwable fillInStackTrace() {
            return this;
        }
    }

    /** The owner (channel id, name, picture) of a video: the web watch data read only as far as its owner (~20 KB). */
    private WebRelated webOwner(String videoId) throws IOException {
        return webRelated(videoId, true);
    }

    /** A channel picture URL at tile size (the watch data sends 48-88 px ones; some are protocol-relative). */
    private static String avatarUrl(String url) {
        if (url == null || url.isEmpty()) return "";
        if (url.startsWith("//")) url = "https:" + url;
        return url.replaceFirst("=s\\d+-", "=s240-");
    }

    /** What the related-column read never builds (the answer is ~0.5 MB; only the column's tiles are kept). */
    private static final Set<String> RELATED_SKIP = new HashSet<>(Arrays.asList("frameworkUpdates", "responseContext",
            "engagementPanels", "playerOverlays", "topbar", "trackingParams", "clickTrackingParams", "loggingDirectives",
            "loggingContext", "commandMetadata", "accessibility", "accessibilityData", "menuButton", "menu",
            "animatedThumbnailOverlayViewModel", "lottieData", "attributedDescription", "description",
            "videoPrimaryInfoRenderer", "metadataRowContainer", "subscribeButton", "sponsorButton", "subscriptionButton"));
    private static final Set<String> RELATED_CAPTURE = new HashSet<>(Arrays.asList("lockupViewModel", "videoOwnerRenderer"));
    /** The source video's read also keeps the description's game and music cards (in its engagement panel). */
    private static final Set<String> DESCRIBED_SKIP = new HashSet<>(RELATED_SKIP);
    private static final Set<String> DESCRIBED_CAPTURE = new HashSet<>(Arrays.asList("lockupViewModel", "videoOwnerRenderer",
            "videoAttributesSectionViewModel", "horizontalCardListRenderer"));

    static {
        DESCRIBED_SKIP.remove("engagementPanels");
    }

    /** The web watch data ("next", signed out, as {@link #chapters}): related videos with their channels, and the owner. */
    private WebRelated webRelated(String videoId) throws IOException {
        return webRelated(videoId, false);
    }

    private WebRelated webRelated(String videoId, final boolean ownerOnly) throws IOException {
        return webRelated(videoId, ownerOnly, false);
    }

    /** As {@link #webRelated(String)}; {@code described}: with the description's game and music cards. */
    private WebRelated webRelated(String videoId, final boolean ownerOnly, final boolean described) throws IOException {
        final WebRelated out = new WebRelated();
        try {
            JSONObject client = new JSONObject().put("clientName", "WEB").put("clientVersion", WEB_VERSION).put("hl", "en").put("gl", "US");
            JSONObject nb = new JSONObject().put("videoId", videoId).put("context", new JSONObject().put("client", client));
            Map<String, String> h = new HashMap<>();
            h.put("User-Agent", Http.DESKTOP_UA);
            h.put("Origin", "https://www.youtube.com");
            try (Http.Response r = Http.open(API + "next?prettyPrint=false", h, nb.toString().getBytes(StandardCharsets.UTF_8),
                    "application/json", true)) {
                JsonReader jr = new JsonReader(new InputStreamReader(r.body, StandardCharsets.UTF_8));
                JsonScan.scan(jr, described ? DESCRIBED_CAPTURE : RELATED_CAPTURE, NONE, described ? DESCRIBED_SKIP : RELATED_SKIP, new JsonScan.Sink() {
                    @Override
                    public void onValue(String key, String name, JSONObject v) {
                        if (key.equals("videoAttributesSectionViewModel") || key.equals("horizontalCardListRenderer")) {
                            cards(v, key.equals("videoAttributesSectionViewModel") ? out.games : out.music, key.equals("horizontalCardListRenderer"));
                            return;
                        }
                        if (key.equals("videoOwnerRenderer")) {
                            JSONObject be = JsonScan.path(v, "navigationEndpoint", "browseEndpoint");
                            if (be != null && out.ownerId.isEmpty()) {
                                out.ownerId = be.optString("browseId", "");
                                out.ownerName = JsonScan.text(v.optJSONObject("title"));
                                JSONObject th = v.optJSONObject("thumbnail");
                                JSONArray ts = th == null ? null : th.optJSONArray("thumbnails");
                                if (ts != null && ts.length() > 0 && ts.optJSONObject(ts.length() - 1) != null)
                                    out.ownerAvatar = avatarUrl(ts.optJSONObject(ts.length() - 1).optString("url", ""));
                                if (ownerOnly) throw new OwnerFound();
                            }
                            return;
                        }
                        if (ownerOnly) return;
                        Item x = webLockup(v);
                        if (x != null) out.items.add(x);
                    }
                });
            }
        } catch (OwnerFound done) {
            // the owner is all that was asked for: the rest of the answer is never read
        } catch (JSONException e) {
            throw new IOException("YouTube sent an unreadable video answer");
        }
        return out;
    }

    /** The titles (and with {@code subtitles}, the second lines: a song's artist) of a description's cards. */
    private static void cards(Object o, List<String> out, boolean subtitles) {
        if (o instanceof JSONArray) {
            JSONArray a = (JSONArray) o;
            for (int i = 0; i < a.length(); i++) cards(a.opt(i), out, subtitles);
            return;
        }
        if (!(o instanceof JSONObject)) return;
        JSONObject j = (JSONObject) o;
        JSONObject card = j.optJSONObject("videoAttributeViewModel");
        if (card != null) {
            String t = attrText(card.opt("title"));
            if (!t.isEmpty() && out.size() < 6) out.add(t);
            String st = subtitles ? attrText(card.opt("subtitle")) : "";
            if (!st.isEmpty() && out.size() < 6) out.add(st);
            return;
        }
        java.util.Iterator<String> ks = j.keys();
        while (ks.hasNext()) cards(j.opt(ks.next()), out, subtitles);
    }

    private static String attrText(Object o) {
        if (o instanceof String) return ((String) o).trim();
        return o instanceof JSONObject ? JsonScan.text((JSONObject) o).trim() : "";
    }

    /** What the web player answer keeps for the descriptor: its video details and category, never its streams. */
    private static final Set<String> META_CAPTURE = new HashSet<>(Arrays.asList("videoDetails", "playerMicroformatRenderer"));
    private static final Set<String> META_SKIP = new HashSet<>(Arrays.asList("streamingData", "playerConfig", "storyboards",
            "playbackTracking", "captions", "annotations", "attestation", "adPlacements", "playerAds", "endscreen",
            "thumbnail", "thumbnails", "responseContext", "frameworkUpdates", "trackingParams", "embed", "availableCountries"));

    /**
     * A video's own metadata for {@link Descriptor}: title, tags, description, category and channel, from the web
     * player answer (signed out; it carries them even when it will not play the video there).
     */
    private Descriptor.Source webMeta(String videoId) throws IOException {
        final Descriptor.Source out = new Descriptor.Source();
        try {
            JSONObject client = new JSONObject().put("clientName", "WEB").put("clientVersion", WEB_VERSION).put("hl", "en").put("gl", "US");
            JSONObject body = new JSONObject().put("videoId", videoId).put("contentCheckOk", true).put("racyCheckOk", true)
                    .put("context", new JSONObject().put("client", client));
            Map<String, String> h = new HashMap<>();
            h.put("User-Agent", Http.DESKTOP_UA);
            h.put("Origin", "https://www.youtube.com");
            try (Http.Response r = Http.open(API + "player?prettyPrint=false", h, body.toString().getBytes(StandardCharsets.UTF_8),
                    "application/json", true)) {
                JsonReader jr = new JsonReader(new InputStreamReader(r.body, StandardCharsets.UTF_8));
                JsonScan.scan(jr, META_CAPTURE, NONE, META_SKIP, new JsonScan.Sink() {
                    @Override
                    public void onValue(String key, String name, JSONObject v) {
                        if (key.equals("playerMicroformatRenderer")) {
                            out.category = v.optString("category", "");
                            return;
                        }
                        out.title = v.optString("title", "");
                        out.owner = v.optString("author", "");
                        out.description = v.optString("shortDescription", "");
                        JSONArray kw = v.optJSONArray("keywords");
                        if (kw != null) for (int i = 0; i < kw.length() && i < 60; i++) out.keywords.add(kw.optString(i));
                    }
                });
            }
        } catch (JSONException e) {
            throw new IOException("YouTube sent an unreadable player answer");
        }
        return out;
    }

    private static final Set<String> SEARCH_CAPTURE = new HashSet<>(Arrays.asList("videoRenderer"));
    private static final Set<String> SEARCH_SKIP = new HashSet<>(Arrays.asList("responseContext", "frameworkUpdates",
            "trackingParams", "clickTrackingParams", "loggingDirectives", "commandMetadata", "accessibility",
            "accessibilityData", "menu", "watchEndpointSupportedOnesieConfig", "thumbnailOverlays", "richThumbnail",
            "inlinePlaybackEndpoint", "adSlotRenderer", "reelShelfRenderer",
            "shelfRenderer", "searchPyvRenderer", "estimatedResults", "refinements", "topbar"));

    /**
     * A web search for videos (signed out, as the web page searches): each video with its channel, and its
     * description snippet in {@code snippets}. {@code filter} null is the Videos filter; a value such as the
     * "This month" filter restricts uploads.
     */
    private List<Item> webSearch(String query, Map<String, String> snippets, String filter) throws IOException {
        final List<Item> out = new ArrayList<>();
        final Map<String, String> sn = snippets;
        try {
            JSONObject client = new JSONObject().put("clientName", "WEB").put("clientVersion", WEB_VERSION).put("hl", "en").put("gl", "US");
            // params: videos only (the search page's "Videos" filter)
            String params = filter == null || filter.isEmpty()
                    ? Config.s("youtube.similar.videoParams", "EgIQAQ%3D%3D") : filter;
            JSONObject body = new JSONObject().put("query", query).put("params", params)
                    .put("context", new JSONObject().put("client", client));
            Map<String, String> h = new HashMap<>();
            h.put("User-Agent", Http.DESKTOP_UA);
            h.put("Origin", "https://www.youtube.com");
            try (Http.Response r = Http.open(API + "search?prettyPrint=false", h, body.toString().getBytes(StandardCharsets.UTF_8),
                    "application/json", true)) {
                JsonReader jr = new JsonReader(new InputStreamReader(r.body, StandardCharsets.UTF_8));
                JsonScan.scan(jr, SEARCH_CAPTURE, NONE, SEARCH_SKIP, new JsonScan.Sink() {
                    @Override
                    public void onValue(String key, String name, JSONObject v) {
                        String id = v.optString("videoId", "");
                        if (!id.matches("[A-Za-z0-9_-]{11}")) return;
                        JSONObject owner = v.optJSONObject("ownerText");
                        JSONArray runs = owner == null ? null : owner.optJSONArray("runs");
                        JSONObject run = runs == null ? null : runs.optJSONObject(0);
                        JSONObject be = run == null ? null : JsonScan.path(run, "navigationEndpoint", "browseEndpoint");
                        String cid = be == null ? "" : be.optString("browseId", "");
                        String cname = run == null ? "" : run.optString("text", "");
                        if (!cid.startsWith("UC") || cname.isEmpty()) return;
                        String views = JsonScan.text(v.optJSONObject("shortViewCountText"));
                        String age = JsonScan.text(v.optJSONObject("publishedTimeText"));
                        boolean live = age.isEmpty() && views.contains("watching");
                        StringBuilder sub = new StringBuilder(cname);
                        if (!views.isEmpty()) sub.append(" · ").append(views);
                        if (!age.isEmpty()) sub.append(" · ").append(age);
                        String len = JsonScan.text(v.optJSONObject("lengthText"));
                        Item x = new Item(live ? Item.LIVE : Item.VIDEO, id, JsonScan.text(v.optJSONObject("title")), sub.toString(),
                                "https://i.ytimg.com/vi/" + id + "/mqdefault.jpg", live ? "LIVE" : len, "");
                        // the channel's picture comes with each result, so a channel found only here needs no lookup
                        JSONObject cth = JsonScan.path(v, "channelThumbnailSupportedRenderers", "channelThumbnailWithLinkRenderer", "thumbnail");
                        JSONArray cts = cth == null ? null : cth.optJSONArray("thumbnails");
                        JSONObject ct = cts == null || cts.length() == 0 ? null : cts.optJSONObject(cts.length() - 1);
                        String cimg = ct == null ? "" : avatarUrl(ct.optString("url", ""));
                        x.channel = new Item(Item.CHANNEL, cid, cname, "Channel", cimg, "", "");
                        JSONArray snips = v.optJSONArray("detailedMetadataSnippets");
                        StringBuilder t = new StringBuilder();
                        if (snips != null) for (int i = 0; i < snips.length(); i++) {
                            JSONObject o = snips.optJSONObject(i);
                            if (o != null) t.append(JsonScan.text(o.optJSONObject("snippetText"))).append(' ');
                        }
                        if (t.length() > 0 && sn != null) sn.put(id, t.toString().trim());
                        out.add(x);
                    }
                });
            }
        } catch (JSONException e) {
            throw new IOException("YouTube sent an unreadable search answer");
        }
        return out;
    }

    /** A related-column video (web lockupViewModel) with its channel (id, name, avatar); null for mixes and playlists. */
    private static Item webLockup(JSONObject l) {
        String type = l.optString("contentType");
        boolean film = "LOCKUP_CONTENT_TYPE_MOVIE".equals(type);
        if (!film && !"LOCKUP_CONTENT_TYPE_VIDEO".equals(type)) return null;
        String id = l.optString("contentId");
        if (!id.matches("[A-Za-z0-9_-]{11}")) return null;
        JSONObject m = JsonScan.path(l, "metadata", "lockupMetadataViewModel");
        if (m == null) return null;
        String commerce = lockupCommerce(m);
        if (film || !commerce.isEmpty()) return webMovie(l, m, id, commerce);
        String title = JsonScan.text(m.optJSONObject("title"));
        JSONArray rows = JsonScan.path(m, "metadata", "contentMetadataViewModel") == null ? null
                : m.optJSONObject("metadata").optJSONObject("contentMetadataViewModel").optJSONArray("metadataRows");
        String channel = "";
        StringBuilder sub = new StringBuilder();
        if (rows != null) for (int i = 0; i < rows.length() && i < 2; i++) {
            JSONArray parts = rows.optJSONObject(i) == null ? null : rows.optJSONObject(i).optJSONArray("metadataParts");
            if (parts == null) continue;
            for (int k = 0; k < parts.length(); k++) {
                JSONObject part = parts.optJSONObject(k);
                String s = JsonScan.text(JsonScan.path(part, "text"));
                if (s.isEmpty()) continue;
                if (i == 0 && k == 0) channel = s;
                // the web column writes "2.6M" with a play icon; the tiles elsewhere say "2.6M views"
                if (i == 1 && k == 0 && s.matches("[\\d.,]+[KMB]?")) s += " views";
                if (sub.length() > 0) sub.append(" · ");
                sub.append(s);
            }
        }
        JSONObject av = JsonScan.path(m, "image", "decoratedAvatarViewModel");
        JSONObject be = av == null ? null : JsonScan.path(av, "rendererContext", "commandContext", "onTap", "innertubeCommand", "browseEndpoint");
        String cid = be == null ? "" : be.optString("browseId", "");
        JSONObject img = av == null ? null : JsonScan.path(av, "avatar", "avatarViewModel", "image");
        JSONArray srcs = img == null ? null : img.optJSONArray("sources");
        String avatar = srcs == null || srcs.length() == 0 ? "" : srcs.optJSONObject(0).optString("url", "");
        // the column's 68 px avatar: ask for a tile-sized one
        avatar = avatarUrl(avatar);
        String badge = "";
        JSONArray ov = JsonScan.path(l, "contentImage", "thumbnailViewModel") == null ? null
                : l.optJSONObject("contentImage").optJSONObject("thumbnailViewModel").optJSONArray("overlays");
        if (ov != null) for (int i = 0; i < ov.length(); i++) {
            JSONObject b = JsonScan.path(ov.optJSONObject(i), "thumbnailBottomOverlayViewModel");
            JSONArray badges = b == null ? null : b.optJSONArray("badges");
            if (badges != null && badges.length() > 0 && badges.optJSONObject(0) != null) {
                JSONObject tb = badges.optJSONObject(0).optJSONObject("thumbnailBadgeViewModel");
                if (tb != null) badge = tb.optString("text");
            }
        }
        boolean live = "LIVE".equalsIgnoreCase(badge);
        Item x = new Item(live ? Item.LIVE : Item.VIDEO, id, title, sub.toString(),
                "https://i.ytimg.com/vi/" + id + "/mqdefault.jpg", live ? "LIVE" : badge, "");
        // a collaboration's avatar opens a list of channels instead: the tile then finds its channel on request
        if (cid.startsWith("UC")) x.channel = new Item(Item.CHANNEL, cid, channel.isEmpty() ? "Channel" : channel, "Channel", avatar, "", "");
        return x;
    }

    /** The lockup's commerce badge (badgeStyle BADGE_COMMERCE: "Free with ads", "Buy or rent"); empty for a video. */
    private static String lockupCommerce(JSONObject m) {
        JSONObject cm = JsonScan.path(m, "metadata", "contentMetadataViewModel");
        JSONArray rows = cm == null ? null : cm.optJSONArray("metadataRows");
        if (rows != null) for (int i = 0; i < rows.length(); i++) {
            JSONArray badges = rows.optJSONObject(i) == null ? null : rows.optJSONObject(i).optJSONArray("badges");
            if (badges != null) for (int k = 0; k < badges.length(); k++) {
                JSONObject b = JsonScan.path(badges.optJSONObject(k), "badgeViewModel");
                if (b != null && "BADGE_COMMERCE".equals(b.optString("badgeStyle"))) {
                    String t = b.optString("badgeText");
                    return t.isEmpty() ? "Movie" : t;
                }
            }
        }
        return "";
    }

    /** A web related-column film (or show) as a YouTube Movies title-page tile with its poster. */
    private static Item webMovie(JSONObject l, JSONObject m, String id, String commerce) {
        String title = JsonScan.text(m.optJSONObject("title"));
        JSONObject cm = JsonScan.path(m, "metadata", "contentMetadataViewModel");
        JSONArray rows = cm == null ? null : cm.optJSONArray("metadataRows");
        StringBuilder sub = new StringBuilder();
        if (rows != null) for (int i = 0; i < rows.length(); i++) {
            JSONArray parts = rows.optJSONObject(i) == null ? null : rows.optJSONObject(i).optJSONArray("metadataParts");
            if (parts != null) for (int k = 0; k < parts.length(); k++) {
                String s = JsonScan.text(JsonScan.path(parts.optJSONObject(k), "text"));
                if (s.isEmpty()) continue;
                if (sub.length() > 0) sub.append(" · ");
                sub.append(s);
            }
        }
        if (!commerce.isEmpty()) sub.append(sub.length() > 0 ? " · " : "").append(commerce);
        JSONObject img = JsonScan.path(l, "contentImage", "thumbnailViewModel", "image");
        JSONArray srcs = img == null ? null : img.optJSONArray("sources");
        String image = srcs == null || srcs.length() == 0 ? "" : srcs.optJSONObject(srcs.length() - 1).optString("url", "");
        if (image.isEmpty()) image = "https://i.ytimg.com/vi/" + id + "/mqdefault.jpg";
        String badge = "";
        JSONArray ov = JsonScan.path(l, "contentImage", "thumbnailViewModel") == null ? null
                : l.optJSONObject("contentImage").optJSONObject("thumbnailViewModel").optJSONArray("overlays");
        if (ov != null) for (int i = 0; i < ov.length(); i++) {
            JSONArray badges = JsonScan.path(ov.optJSONObject(i), "thumbnailBottomOverlayViewModel") == null ? null
                    : ov.optJSONObject(i).optJSONObject("thumbnailBottomOverlayViewModel").optJSONArray("badges");
            JSONObject tb = badges == null || badges.length() == 0 ? null : JsonScan.path(badges.optJSONObject(0), "thumbnailBadgeViewModel");
            if (tb != null) badge = tb.optString("text");
        }
        Item x = new Item(Item.PAGE, "MV" + id, title, sub.toString(), image, badge, "");
        x.commerce = commerce.isEmpty() ? "Movie" : commerce;
        return x;
    }

    // ------------------------------------------------------------------ don't recommend channel

    /** Menus described in the log per answer while the entry is not found (labels only, never tokens). */
    private static volatile int menuLogs;

    /**
     * Reads a video tile's long-press menu (kept only when signed in): the "Don't recommend channel" entry's
     * feedback token and, when the entry carries one, its undo token; and the channel from "Go to channel".
     */
    private static void readMenu(Item it, JSONObject menu, JSONObject tile) {
        if (it == null || (it.kind != Item.VIDEO && it.kind != Item.LIVE)) return;
        if (menu == null) {
            if (menuLogs < 2) {
                menuLogs++;
                Log.i(TAG, "tile without a long-press menu: " + keysOf(tile, 0));
            }
            return;
        }
        String[] ch = {null};
        List<String> labels = new ArrayList<>();
        readMenu(it, menu, ch, labels, 0);
        if (it.channel == null && ch[0] != null) it.channel = channelTile(ch[0], channelName(it.subtitle));
        if (it.hideToken == null && it.hideMenu == null && menuLogs < 2) {
            menuLogs++;
            Log.i(TAG, "tile menu without don't-recommend-channel: " + labels + " " + keysOf(menu, 0));
        }
    }

    private static void readMenu(Item it, Object o, String[] ch, List<String> labels, int depth) {
        if (depth > 40 || it.hideToken != null) return;
        if (o instanceof JSONArray) {
            JSONArray a = (JSONArray) o;
            for (int i = 0; i < a.length(); i++) readMenu(it, a.opt(i), ch, labels, depth + 1);
            return;
        }
        if (!(o instanceof JSONObject)) return;
        JSONObject j = (JSONObject) o;
        // the TV app's long press opens a panel fetched on demand (get_panel): remember how to ask for it
        JSONObject sp = j.optJSONObject("showEngagementPanelEndpoint");
        if (sp != null && it.hideMenu == null) {
            String tag = sp.optString("panelIdentifier", "");
            if (tag.isEmpty()) tag = JsonScan.path(sp, "identifier") == null ? "" : sp.optJSONObject("identifier").optString("tag", "");
            String params = JsonScan.path(sp, "globalConfiguration") == null ? ""
                    : sp.optJSONObject("globalConfiguration").optString("params", "");
            if (!tag.isEmpty() || !params.isEmpty()) it.hideMenu = tag + "\n" + params;
        }
        JSONObject b = j.optJSONObject("browseEndpoint");
        if (ch[0] == null && b != null && b.optString("browseId").startsWith("UC")) ch[0] = b.optString("browseId");
        String label = menuLabel(j);
        if (!label.isEmpty()) {
            if (labels.size() < 12) labels.add(label);
            if (isHideLabel(label)) {
                JSONObject fe = findKey(j, "feedbackEndpoint", 0);
                if (fe != null && !fe.optString("feedbackToken").isEmpty()) {
                    it.hideToken = fe.optString("feedbackToken");
                    JSONObject undo = findKey(j, "undoFeedbackEndpoint", 0);
                    if (undo != null && !undo.optString("undoToken").isEmpty()) it.hideUndo = undo.optString("undoToken");
                    return;
                }
            }
        }
        for (java.util.Iterator<String> i = j.keys(); i.hasNext(); ) readMenu(it, j.opt(i.next()), ch, labels, depth + 1);
    }

    /** The key outline of a JSON object (keys only, three levels), for the log. */
    private static String keysOf(Object o, int depth) {
        if (!(o instanceof JSONObject) || depth > 2) return "";
        StringBuilder b = new StringBuilder("{");
        JSONObject j = (JSONObject) o;
        for (java.util.Iterator<String> i = j.keys(); i.hasNext(); ) {
            String k = i.next();
            b.append(k).append(keysOf(j.opt(k), depth + 1)).append(i.hasNext() ? "," : "");
        }
        return b.append("}").toString();
    }

    /** The text of a menu entry (menuServiceItemRenderer "text", listItemViewModel "title"), else empty. */
    private static String menuLabel(JSONObject j) {
        for (String k : new String[]{"text", "title"}) {
            JSONObject t = j.optJSONObject(k);
            if (t != null) {
                String s = JsonScan.text(t);
                if (!s.isEmpty()) return s;
            }
        }
        return "";
    }

    private static boolean isHideLabel(String label) {
        String l = label.toLowerCase(java.util.Locale.ROOT).replace('\u2019', '\'');
        for (String h : HIDE_LABELS) if (l.contains(h)) return true;
        return false;
    }

    /** The channel part of a tile's second line ("Channel · 1M views · 2 days ago"). */
    private static String channelName(String sub) {
        int dot = sub.indexOf(" · ");
        return (dot < 0 ? sub : sub.substring(0, dot)).trim();
    }

    /** Fetches the tile's menu panel (get_panel, as the TV app does on a long press) and reads the entry from it. */
    @Override
    public boolean resolveHide(Item it) throws IOException {
        if (it.hideToken != null) return true;
        String m = it.hideMenu;
        if (m == null || !signedIn()) return false;
        int nl = m.indexOf('\n');
        JSONObject body;
        try {
            JSONObject req = new JSONObject();
            if (nl > 0) req.put("panelId", m.substring(0, nl));
            if (nl + 1 < m.length()) req.put("params", m.substring(nl + 1));
            body = tvContext(req);
        } catch (JSONException e) {
            throw new IOException(e);
        }
        JSONObject o;
        try (Http.Response r = call("get_panel", body, true)) {
            o = new JSONObject(new String(Http.readAll(r.body, 2 << 20), StandardCharsets.UTF_8));
        } catch (JSONException e) {
            throw new IOException("YouTube's menu could not be read.");
        }
        it.hideMenu = null;
        String[] ch = {null};
        List<String> labels = new ArrayList<>();
        readMenu(it, o, ch, labels, 0);
        if (it.channel == null && ch[0] != null) it.channel = channelTile(ch[0], channelName(it.subtitle));
        Log.i(TAG, "tile menu " + labels + (it.hideToken == null ? ": no don't-recommend-channel"
                : ": don't recommend channel" + (it.hideUndo != null ? " (with undo)" : "")));
        return it.hideToken != null;
    }

    @Override
    public String hideLabel(Item it) {
        return it.hideToken != null && signedIn() ? "Don't recommend channel" : null;
    }

    /** Posts the tile's feedback token to youtubei "feedback", as the TV app's menu does; returns the undo token. */
    @Override
    public String hide(Item it) throws IOException {
        if (it.hideToken == null) throw new IOException("YouTube gave no option for this video.");
        JSONObject o = feedback(it.hideToken);
        if (it.hideUndo != null) return it.hideUndo;
        JSONObject undo = findKey(o, "undoFeedbackEndpoint", 0);
        return undo == null || undo.optString("undoToken").isEmpty() ? null : undo.optString("undoToken");
    }

    @Override
    public void undoHide(String undoToken) throws IOException {
        feedback(undoToken);
    }

    private JSONObject feedback(String token) throws IOException {
        if (!signedIn()) throw new IOException("Sign in to YouTube first.");
        JSONObject body;
        try {
            body = tvContext(new JSONObject().put("feedbackTokens", new JSONArray().put(token))
                    .put("isFeedbackTokenUnencrypted", false).put("shouldMerge", false));
        } catch (JSONException e) {
            throw new IOException(e);
        }
        JSONObject o;
        int code;
        // the token comes from the TV client's own menu (get_panel), so it goes back with the same TV context and sign-in
        Log.i(TAG, "feedback: sending a " + token.length() + "-char token, TV client, signed in");
        try (Http.Response r = call("feedback", body, true)) {
            code = r.code;
            o = new JSONObject(new String(Http.readAll(r.body, 256 << 10), StandardCharsets.UTF_8));
        } catch (Http.Error e) {
            Log.w(TAG, "feedback: HTTP " + e.code);
            throw e;
        } catch (JSONException e) {
            throw new IOException("YouTube's answer could not be read.");
        }
        JSONArray rs = o.optJSONArray("feedbackResponses");
        boolean ok = rs != null && rs.length() > 0 && rs.optJSONObject(0) != null && rs.optJSONObject(0).optBoolean("isProcessed");
        Log.i(TAG, "feedback: HTTP " + code + ", feedbackResponses " + (rs == null ? "none" : clip(rs.toString()))
                + ", processed " + ok + " " + keysOf(o, 1));
        if (!ok) throw new IOException("YouTube didn't take it. Try again later.");
        return o;
    }

    private static String clip(String s) {
        return s.length() > 160 ? s.substring(0, 160) + "…" : s;
    }

    @Override
    public String[] channelKey(Item x) {
        if (x.kind == Item.CHANNEL) return x.id.startsWith("UC") ? new String[]{x.id, x.title} : null;
        if (x.kind != Item.VIDEO && x.kind != Item.LIVE) return null;
        String id = x.channel != null && x.channel.id.startsWith("UC") ? x.channel.id : "";
        String n = x.channel != null && !x.channel.title.equals("Channel") ? x.channel.title : "";
        if (n.isEmpty()) n = channelName(x.subtitle);
        // a second line without the channel ("1M views", "3 days ago") names no channel
        if (n.matches("(?i).*\\d.*\\b(views?|watching|ago)\\b.*")) n = "";
        return id.isEmpty() && n.isEmpty() ? null : new String[]{id, n};
    }

    private static Item channelTile(String id, String name) {
        return new Item(Item.CHANNEL, id, name.isEmpty() ? "Channel" : name, "", "", "", "");
    }

    /** First object under {@code key}, depth-first. */
    private static JSONObject findKey(Object o, String key, int depth) {
        if (depth > 40) return null;
        if (o instanceof JSONObject) {
            JSONObject j = (JSONObject) o;
            JSONObject hit = j.optJSONObject(key);
            if (hit != null) return hit;
            for (java.util.Iterator<String> i = j.keys(); i.hasNext(); ) {
                JSONObject r = findKey(j.opt(i.next()), key, depth + 1);
                if (r != null) return r;
            }
        } else if (o instanceof JSONArray) {
            JSONArray a = (JSONArray) o;
            for (int i = 0; i < a.length(); i++) {
                JSONObject r = findKey(a.opt(i), key, depth + 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    @Override
    public Item.Page open(Item item) throws IOException {
        return browse(item.id, item.extra);
    }

    /** Playlists (and mixes) open as the shared title page with their videos in the episode grid. */
    @Override
    public boolean opensDetail(Item item) {
        return item.kind == Item.SERIES || (item.kind == Item.PAGE && item.id.startsWith("VL"));
    }

    @Override
    public Item.Page openDetail(Item item) throws IOException {
        Item.Page p = super.openDetail(item);
        if (p.detail != null && p.detail.play != null) p.detail.playLabel = "Play all";
        // a playlist is one list: keep the grid on its videos even when YouTube splits it into several shelves
        if (!p.seasons.isEmpty()) {
            Item.Shelf all = new Item.Shelf("Videos", new ArrayList<Item>());
            for (Item.Season s : p.seasons) all.items.addAll(s.episodes.items);
            p.seasons.clear();
            p.shelves.clear();
            p.shelves.add(all);
            p.grid = 0;
        }
        return p;
    }

    private Item.Page shelves(String endpoint, JSONObject extra) throws IOException {
        return shelves(endpoint, extra, true);
    }

    private Item.Page shelves(String endpoint, JSONObject extra, boolean auth) throws IOException {
        final Item.Page page = new Item.Page();
        final String[] visitor = {extra.optString(VISITOR, "")};
        final String what = extra.optString("browseId", extra.has("query") ? "search" : "continuation");
        byte[] raw;
        try (Http.Response r = call(endpoint, tvContext(extra), auth)) {
            raw = Http.readAll(r.body, 8 << 20);
        }
        {
            JsonReader jr = new JsonReader(new InputStreamReader(new java.io.ByteArrayInputStream(raw), StandardCharsets.UTF_8));
            menuLogs = 0;
            JsonScan.scan(jr, CAPTURE, NONE, auth && signedIn() ? SKIP_MENU : SKIP, new JsonScan.Sink() {
                @Override
                public void onValue(String key, String name, JSONObject v) {
                    switch (key) {
                        case "responseContext":
                            if (!v.optString("visitorData").isEmpty()) visitor[0] = v.optString("visitorData");
                            return;
                        case "nextContinuationData":
                            page.more = v.optString("continuation", null);
                            return;
                        case "horizontalListContinuation": {
                            // a row's next tiles (moreRow)
                            Item.Shelf s = new Item.Shelf("", items(v.optJSONArray("items"), ""));
                            s.more = nextToken(v.optJSONArray("continuations"));
                            page.shelves.add(s);
                            return;
                        }
                        case "gridContinuation": {
                            // a long grid's next tiles (more): they continue the grid
                            page.shelves.add(new Item.Shelf("", items(v.optJSONArray("items"), "")));
                            page.more = nextToken(v.optJSONArray("continuations"));
                            page.moreExtendsGrid = true;
                            return;
                        }
                        default:
                            collect(key, v, page);
                    }
                }
            });
        }
        // a continuation is only honoured for the visitor whose answer it came from
        if (!visitor[0].isEmpty()) {
            String vd = "\n" + visitor[0];
            if (page.more != null && !page.more.startsWith(SHORTS)) page.more += vd;
            for (Item.Shelf s : page.shelves) if (s.more != null) s.more += vd;
        }
        if (page.isEmpty() && !extra.has("continuation")) deepRows(raw, page, what, auth);
        if (page.isEmpty() && page.empty.isEmpty()) page.empty = "Nothing here yet.";
        return page;
    }

    /**
     * Rows from one captured renderer: a shelf; a grid (a long feed such as History or a playlist list; at most one
     * per page is laid out as the grid); or the signed-in section tabs of Subscriptions and Library (each tab a
     * tile: a channel, History, Watch later, Liked videos, a playlist) with the open tab's own rows.
     */
    private static void collect(String key, JSONObject v, Item.Page page) {
        switch (key) {
            case "shelfRenderer": {
                Item.Shelf s = parseShelf(v);
                if (s != null) page.shelves.add(s);
                break;
            }
            case "gridRenderer": {
                String title = JsonScan.text(JsonScan.path(v, "header", "gridHeaderRenderer", "title"));
                Item.Shelf s = new Item.Shelf(title, items(v.optJSONArray("items"), title));
                if (s.items.isEmpty()) break;
                if (page.grid < 0) {
                    page.shelves.add(s);
                    page.grid = page.shelves.size() - 1;
                    String more = nextToken(v.optJSONArray("continuations"));
                    if (more != null) {
                        page.more = more;
                        page.moreExtendsGrid = true;
                    }
                } else {
                    page.shelves.add(s);
                }
                break;
            }
            case "tvSecondaryNavRenderer": {
                JSONArray sections = v.optJSONArray("sections");
                List<Item> tabs = new ArrayList<>();
                List<JSONObject> contents = new ArrayList<>();
                String heading = "";
                if (sections != null) for (int i = 0; i < sections.length(); i++) {
                    JSONObject sec = JsonScan.path(sections.optJSONObject(i), "tvSecondaryNavSectionRenderer");
                    if (sec == null) continue;
                    if (heading.isEmpty()) heading = JsonScan.text(sec.optJSONObject("title"));
                    JSONArray ts = sec.optJSONArray("tabs");
                    if (ts != null) for (int k = 0; k < ts.length(); k++) {
                        JSONObject tab = JsonScan.path(ts.optJSONObject(k), "tabRenderer");
                        if (tab == null) continue;
                        if (tab.optJSONObject("content") != null) contents.add(tab.optJSONObject("content"));
                        String title = JsonScan.text(tab.optJSONObject("title"));
                        JSONObject th = tab.optJSONObject("thumbnail");
                        String image = th == null ? "" : bestThumb(th.optJSONArray("thumbnails"));
                        Item it = fromCommand(tab.optJSONObject("endpoint"), title, "", image, "", "");
                        if (it != null && !title.isEmpty()) tabs.add(it);
                    }
                }
                if (!tabs.isEmpty()) page.shelves.add(new Item.Shelf(heading.isEmpty() ? "Sections" : heading, tabs));
                for (JSONObject c : contents) walk(c, page, 0);
                break;
            }
            default:
                break;
        }
    }

    /**
     * Last resort for an answer the streaming scan found no rows in: parse it whole and take any list of tiles
     * (tileRenderer / lockupViewModel) wherever it sits, so a new wrapper renderer does not empty the page.
     * Logs the answer's renderer names (never its contents) so an empty page can be diagnosed from logcat.
     */
    private static void deepRows(byte[] raw, Item.Page page, String what, boolean auth) {
        try {
            JSONObject o = new JSONObject(new String(raw, StandardCharsets.UTF_8));
            deepWalk(o, "", page, 0);
            if (page.isEmpty()) titlePage(o, page);
            if (page.isEmpty()) {
                Map<String, Integer> names = new java.util.TreeMap<>();
                countRenderers(o, names, 0);
                Log.w(TAG, "no rows in " + what + " (" + raw.length + " bytes, " + (auth ? "account" : "signed out")
                        + "); renderers: " + names);
            } else {
                Log.i(TAG, what + ": " + page.shelves.size() + " rows from the deep parse");
            }
        } catch (JSONException e) {
            Log.w(TAG, "no rows in " + what + ": unreadable answer (" + raw.length + " bytes)");
        }
    }

    /**
     * A YouTube Movies / TV title page (an "MV" movie or "SC" show: a channelHeaderRenderer with buttons and no
     * rows): its watch buttons (Play movie, Trailer, episodes) become one row; a title only sold or rented on
     * YouTube says so instead of "Nothing here yet.".
     */
    private static void titlePage(JSONObject o, Item.Page page) {
        JSONObject h = JsonScan.path(o, "contents", "tvBrowseRenderer", "content", "tvSurfaceContentRenderer", "header",
                "channelHeaderRenderer");
        if (h == null) return;
        String title = JsonScan.text(h.optJSONObject("title"));
        String desc = JsonScan.text(JsonScan.path(h, "selectableDescription", "selectableTextRenderer", "compactDescription"));
        String meta = "";
        JSONArray md = h.optJSONArray("metadata");
        if (md != null && md.length() > 0) meta = JsonScan.text(JsonScan.path(md.optJSONObject(0), "lineRenderer") == null ? null
                : JsonScan.path(md.optJSONObject(0).optJSONObject("lineRenderer").optJSONArray("items").optJSONObject(0), "lineItemRenderer", "text"));
        List<Item> items = new ArrayList<>();
        JSONArray buttons = h.optJSONArray("buttons");
        if (buttons != null) for (int i = 0; i < buttons.length(); i++) {
            JSONObject bt = JsonScan.path(buttons.optJSONObject(i), "buttonRenderer");
            JSONObject w = bt == null ? null : JsonScan.path(bt, "navigationEndpoint", "watchEndpoint");
            if (w == null || w.optString("videoId").isEmpty()) continue;
            String label = JsonScan.text(bt.optJSONObject("text"));
            String id = w.optString("videoId");
            Item it = new Item(Item.VIDEO, id, label.isEmpty() ? title : label + ": " + title, meta,
                    "https://i.ytimg.com/vi/" + id + "/mqdefault.jpg", "", "");
            it.description = desc;
            items.add(it);
        }
        if (!items.isEmpty()) {
            page.shelves.add(new Item.Shelf(title, items));
        } else {
            page.empty = (title.isEmpty() ? "This title" : title) + " is only available to buy, rent or with a membership on YouTube.";
        }
        Log.i(TAG, "title page " + title + ": " + items.size() + " watch buttons");
    }

    private static void deepWalk(Object o, String title, Item.Page page, int depth) {
        if (depth > 30) return;
        if (o instanceof JSONObject) {
            JSONObject j = (JSONObject) o;
            String t = JsonScan.text(j.optJSONObject("title"));
            if (t.isEmpty()) t = title;
            for (java.util.Iterator<String> it = j.keys(); it.hasNext(); ) {
                String k = it.next();
                Object v = j.opt(k);
                if (v instanceof JSONArray && looksLikeTiles((JSONArray) v)) {
                    List<Item> items = items((JSONArray) v, t);
                    if (!items.isEmpty()) page.shelves.add(new Item.Shelf(t, items));
                } else if (!SKIP.contains(k)) {
                    deepWalk(v, t, page, depth + 1);
                }
            }
        } else if (o instanceof JSONArray) {
            JSONArray a = (JSONArray) o;
            for (int i = 0; i < a.length(); i++) deepWalk(a.opt(i), title, page, depth + 1);
        }
    }

    private static boolean looksLikeTiles(JSONArray a) {
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && (x.has("tileRenderer") || x.has("lockupViewModel"))) return true;
        }
        return false;
    }

    private static void countRenderers(Object o, Map<String, Integer> names, int depth) {
        if (depth > 30) return;
        if (o instanceof JSONObject) {
            JSONObject j = (JSONObject) o;
            for (java.util.Iterator<String> it = j.keys(); it.hasNext(); ) {
                String k = it.next();
                if (k.endsWith("Renderer") || k.endsWith("ViewModel") || k.equals("alerts") || k.equals("error")) {
                    Integer n = names.get(k);
                    names.put(k, n == null ? 1 : n + 1);
                }
                countRenderers(j.opt(k), names, depth + 1);
            }
        } else if (o instanceof JSONArray) {
            JSONArray a = (JSONArray) o;
            for (int i = 0; i < a.length(); i++) countRenderers(a.opt(i), names, depth + 1);
        }
    }

    /** Finds shelves and grids inside a tab's content (they nest a few renderers deep). */
    private static void walk(Object o, Item.Page page, int depth) {
        if (depth > 12) return;
        if (o instanceof JSONObject) {
            JSONObject j = (JSONObject) o;
            for (java.util.Iterator<String> it = j.keys(); it.hasNext(); ) {
                String k = it.next();
                Object v = j.opt(k);
                if ((k.equals("shelfRenderer") || k.equals("gridRenderer")) && v instanceof JSONObject) {
                    collect(k, (JSONObject) v, page);
                } else {
                    walk(v, page, depth + 1);
                }
            }
        } else if (o instanceof JSONArray) {
            JSONArray a = (JSONArray) o;
            for (int i = 0; i < a.length(); i++) walk(a.opt(i), page, depth + 1);
        }
    }

    private static String nextToken(JSONArray continuations) {
        if (continuations == null) return null;
        for (int i = 0; i < continuations.length(); i++) {
            JSONObject n = JsonScan.path(continuations.optJSONObject(i), "nextContinuationData");
            if (n != null && !n.optString("continuation").isEmpty()) return n.optString("continuation");
        }
        return null;
    }

    private JSONObject tvContext(JSONObject extra) throws IOException {
        try {
            JSONObject client = new JSONObject().put("clientName", TV_CLIENT).put("clientVersion", TV_VERSION)
                    .put("hl", "en").put("gl", "US");
            String visitor = (String) extra.remove(VISITOR);
            if (visitor != null && !visitor.isEmpty()) client.put("visitorData", visitor);
            JSONObject ctx = new JSONObject().put("client", client);
            // a brand-account channel picked in the profile picker acts for that channel
            String onBehalf = prefs.getString("on_behalf", "");
            if (!onBehalf.isEmpty()) ctx.put("user", new JSONObject().put("onBehalfOfUser", onBehalf));
            extra.put("context", ctx);
            return extra;
        } catch (JSONException e) {
            throw new IOException(e);
        }
    }

    private Http.Response call(String endpoint, JSONObject body, boolean auth) throws IOException {
        Map<String, String> h = new HashMap<>();
        h.put("User-Agent", Http.TV_UA);
        h.put("Origin", "https://www.youtube.com");
        h.put("Referer", "https://www.youtube.com/tv");
        String token = auth ? accessToken() : null;
        if (token != null) h.put("Authorization", "Bearer " + token);
        return Http.open(API + endpoint + "?prettyPrint=false", h, body.toString().getBytes(StandardCharsets.UTF_8),
                "application/json", true);
    }

    private static Item.Shelf parseShelf(JSONObject shelf) {
        String title = JsonScan.text(JsonScan.path(shelf, "headerRenderer", "shelfHeaderRenderer", "avatarLockup",
                "avatarLockupRenderer", "title"));
        if (title.isEmpty()) title = JsonScan.text(shelf.optJSONObject("title"));
        JSONObject list = JsonScan.path(shelf, "content", "horizontalListRenderer");
        if (list == null) return null;
        Item.Shelf s = new Item.Shelf(title, items(list.optJSONArray("items"), title));
        s.more = nextToken(list.optJSONArray("continuations"));
        return s;
    }

    private static List<Item> items(JSONArray items, String title) {
        List<Item> out = new ArrayList<>();
        if (items != null) {
            for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.optJSONObject(i);
                if (o == null) continue;
                Item it = null;
                if (o.has("tileRenderer")) it = parseTile(o.optJSONObject("tileRenderer"));
                else if (o.has("lockupViewModel")) it = parseLockup(o.optJSONObject("lockupViewModel"));
                if (it != null && it.title.isEmpty() && !title.isEmpty()) {
                    // a shelf's lead "Play all" card is titled only by artwork: name it after the shelf
                    Item named = new Item(it.kind, it.id, title, it.subtitle.isEmpty() ? "Play all" : it.subtitle,
                            it.image, it.badge, it.extra);
                    named.description = it.description;
                    it = named;
                }
                if (it != null) out.add(it);
            }
        }
        return out;
    }

    private static Item parseTile(JSONObject t) {
        if (t == null) return null;
        JSONObject md = JsonScan.path(t, "metadata", "tileMetadataRenderer");
        if (md == null || md.optJSONObject("title") == null) {
            // "elevated" music shelves carry the title and lines in an overlay on the thumbnail instead
            JSONArray hov = JsonScan.path(t, "header", "tileHeaderRenderer") == null ? null
                    : JsonScan.path(t, "header", "tileHeaderRenderer").optJSONArray("thumbnailOverlays");
            if (hov != null) for (int i = 0; i < hov.length(); i++) {
                JSONObject m = JsonScan.path(hov.optJSONObject(i), "tileMetadataRenderer");
                if (m != null && m.optJSONObject("title") != null) {
                    md = m;
                    break;
                }
            }
        }
        String title = JsonScan.text(md == null ? null : md.optJSONObject("title"));
        StringBuilder sub = new StringBuilder();
        JSONArray lines = md == null ? null : md.optJSONArray("lines");
        if (lines != null && lines.length() > 0) {
            JSONArray li = JsonScan.path(lines.optJSONObject(0), "lineRenderer") != null
                    ? JsonScan.path(lines.optJSONObject(0), "lineRenderer").optJSONArray("items") : null;
            if (li != null) for (int i = 0; i < li.length(); i++) {
                String s = JsonScan.text(JsonScan.path(li.optJSONObject(i), "lineItemRenderer", "text"));
                if (s.isEmpty() || s.equals("•")) continue;
                if (sub.length() > 0) sub.append(" · ");
                sub.append(s);
            }
        }
        JSONObject header = JsonScan.path(t, "header", "tileHeaderRenderer");
        String image = bestThumb(JsonScan.path(header, "thumbnail") == null ? null
                : header.optJSONObject("thumbnail").optJSONArray("thumbnails"));
        String badge = "";
        JSONArray ov = header == null ? null : header.optJSONArray("thumbnailOverlays");
        if (ov != null) for (int i = 0; i < ov.length(); i++) {
            JSONObject ts = JsonScan.path(ov.optJSONObject(i), "thumbnailOverlayTimeStatusRenderer");
            if (ts != null) {
                badge = JsonScan.text(ts.optJSONObject("text"));
                if ("LIVE".equals(ts.optString("style"))) badge = "LIVE";
            }
        }
        JSONObject cmd = t.optJSONObject("onSelectCommand");
        Item it = fromCommand(cmd, title, sub.toString(), image, badge, t.optString("contentType"));
        readMenu(it, t.optJSONObject("onLongPressCommand"), t);
        if (it != null) it.commerce = tileCommerce(lines);
        return it;
    }

    /**
     * The tile's YouTube paid-content badge (style BADGE_STYLE_TYPE_YPC: "Free with ads", "Buy or rent", a price), which
     * YouTube puts only on films and shows it sells or streams itself; empty for a creator's video.
     */
    private static String tileCommerce(JSONArray lines) {
        if (lines != null) for (int i = 0; i < lines.length(); i++) {
            JSONObject lr = JsonScan.path(lines.optJSONObject(i), "lineRenderer");
            JSONArray li = lr == null ? null : lr.optJSONArray("items");
            if (li != null) for (int k = 0; k < li.length(); k++) {
                JSONObject b = JsonScan.path(li.optJSONObject(k), "lineItemRenderer", "badge", "metadataBadgeRenderer");
                if (b != null && "BADGE_STYLE_TYPE_YPC".equals(b.optString("style"))) {
                    String label = b.optString("label");
                    return label.isEmpty() ? "Movie" : label;
                }
            }
        }
        return "";
    }

    private static Item parseLockup(JSONObject l) {
        if (l == null) return null;
        String title = JsonScan.text(JsonScan.path(l, "metadata", "lockupMetadataViewModel", "title"));
        StringBuilder sub = new StringBuilder();
        JSONObject cm = JsonScan.path(l, "metadata", "lockupMetadataViewModel", "metadata", "contentMetadataViewModel");
        JSONArray rows = cm == null ? null : cm.optJSONArray("metadataRows");
        if (rows != null) for (int i = 0; i < rows.length() && i < 2; i++) {
            JSONArray parts = rows.optJSONObject(i) == null ? null : rows.optJSONObject(i).optJSONArray("metadataParts");
            if (parts == null) continue;
            for (int k = 0; k < parts.length(); k++) {
                String s = JsonScan.text(JsonScan.path(parts.optJSONObject(k), "text"));
                if (s.isEmpty()) continue;
                if (sub.length() > 0) sub.append(" · ");
                sub.append(s);
            }
        }
        JSONObject img = JsonScan.path(l, "contentImage", "thumbnailViewModel", "image");
        if (img == null) img = JsonScan.path(l, "contentImage", "collectionThumbnailViewModel", "primaryThumbnail",
                "thumbnailViewModel", "image");
        String image = img == null ? "" : bestThumb(img.optJSONArray("sources"));
        String badge = "";
        JSONObject tv = JsonScan.path(l, "contentImage", "thumbnailViewModel");
        JSONArray ov = tv == null ? null : tv.optJSONArray("overlays");
        if (ov != null) for (int i = 0; i < ov.length(); i++) {
            JSONObject b = JsonScan.path(ov.optJSONObject(i), "thumbnailBottomOverlayViewModel");
            JSONArray badges = b == null ? null : b.optJSONArray("badges");
            if (badges != null && badges.length() > 0) {
                badge = JsonScan.path(badges.optJSONObject(0), "thumbnailBadgeViewModel") == null ? ""
                        : badges.optJSONObject(0).optJSONObject("thumbnailBadgeViewModel").optString("text");
            }
        }
        JSONObject cmd = JsonScan.path(l, "rendererContext", "commandContext", "onTap", "innertubeCommand");
        Item it = fromCommand(cmd, title, sub.toString(), image, badge, l.optString("contentType"));
        readMenu(it, JsonScan.path(l, "rendererContext", "commandContext", "onLongPress"), l);
        return it;
    }

    private static Item fromCommand(JSONObject cmd, String title, String sub, String image, String badge, String type) {
        if (cmd == null) return null;
        JSONObject w = cmd.optJSONObject("watchEndpoint");
        if (w == null) w = cmd.optJSONObject("reelWatchEndpoint");
        if (w != null && !w.optString("videoId").isEmpty()) {
            boolean live = "LIVE".equalsIgnoreCase(badge);
            return new Item(live ? Item.LIVE : Item.VIDEO, w.optString("videoId"), title, sub, image, badge, "");
        }
        JSONObject b = cmd.optJSONObject("browseEndpoint");
        if (b != null && !b.optString("browseId").isEmpty()) {
            boolean channel = type.contains("CHANNEL") || b.optString("browseId").startsWith("UC");
            return new Item(channel ? Item.CHANNEL : Item.PAGE, b.optString("browseId"), title, sub, image, badge,
                    b.optString("params"));
        }
        JSONObject pl = cmd.optJSONObject("watchPlaylistEndpoint");
        if (pl != null && !pl.optString("playlistId").isEmpty()) {
            return new Item(Item.PAGE, "VL" + pl.optString("playlistId"), title, sub, image, badge, "");
        }
        return null;
    }

    /** The smallest thumbnail at least 320 px wide; i.ytimg.com video stills use the 320x180 "mq" size. */
    private static String bestThumb(JSONArray a) {
        if (a == null || a.length() == 0) return "";
        String best = null;
        int bestW = Integer.MAX_VALUE;
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.optJSONObject(i);
            if (t == null) continue;
            int w = t.optInt("width", 0);
            if (w >= 320 && w < bestW) {
                bestW = w;
                best = t.optString("url");
            }
        }
        if (best == null) best = a.optJSONObject(a.length() - 1).optString("url");
        if (best.startsWith("//")) best = "https:" + best;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^https://i\\.ytimg\\.com/(vi|vi_webp)/([^/]+)/[^?]+")
                .matcher(best);
        if (m.find()) best = "https://i.ytimg.com/vi/" + m.group(2) + "/mqdefault.jpg";
        return best;
    }

    // ----------------------------------------------------------------------------------- playback

    @Override
    public Playback play(Item item) throws IOException {
        Playback p = new Playback();
        p.title = item.title;
        p.subtitle = item.subtitle;
        // anything that isn't a clear HLS stream plays in YouTube's embed player (WebActivity)
        p.webUrl = "https://www.youtube.com/watch?v=" + item.id;
        p.webTvUa = false;
        // the iOS client still answers live streams with HLS; for videos it now offers only SABR, so skip the call
        if (item.kind != Item.LIVE) return p;
        iosHls(item, p);
        return p;
    }

    /** Asks the iOS client for the clear HLS stream; sets p.hls when YouTube offers one. */
    private void iosHls(Item item, Playback p) throws IOException {
        try {
            JSONObject client = new JSONObject().put("clientName", IOS_CLIENT).put("clientVersion", IOS_VERSION)
                    .put("deviceMake", "Apple").put("deviceModel", "iPhone16,2").put("osName", "iPhone")
                    .put("osVersion", "18.3.2.22D82").put("hl", "en").put("gl", "US");
            JSONObject body = new JSONObject().put("videoId", item.id).put("contentCheckOk", true).put("racyCheckOk", true)
                    .put("context", new JSONObject().put("client", client));
            Map<String, String> h = new HashMap<>();
            h.put("User-Agent", IOS_UA);
            h.put("X-Youtube-Client-Name", "5");
            h.put("X-Youtube-Client-Version", IOS_VERSION);
            JSONObject o = new JSONObject(Http.postJson(API + "player?prettyPrint=false", h, body.toString()));
            String status = JsonScan.path(o, "playabilityStatus") == null ? "" : o.optJSONObject("playabilityStatus").optString("status");
            JSONObject sd = o.optJSONObject("streamingData");
            String hls = sd == null ? null : sd.optString("hlsManifestUrl", null);
            JSONObject vd = o.optJSONObject("videoDetails");
            if (vd != null) {
                p.title = vd.optString("title", p.title);
                p.subtitle = vd.optString("author", p.subtitle);
                p.live = vd.optBoolean("isLive", false) || vd.optBoolean("isLiveContent", false) && item.kind == Item.LIVE;
            }
            if ("OK".equals(status) && hls != null && !hls.isEmpty()) {
                p.hls = hls;
                p.userAgent = IOS_UA;
            } else {
                Log.i(TAG, "no clear stream for " + item.id + " (" + status + "); using the embed player");
            }
        } catch (JSONException e) {
            throw new IOException(e);
        }
    }

    // ------------------------------------------------------------------------------------ account

    @Override public int signInKind() { return SIGNIN_CODE; }

    @Override
    public String codeHelp() {
        return "On your phone or computer, go to";
    }

    @Override
    public Code startCode() throws IOException {
        String dev = prefs.getString("device_id", null);
        if (dev == null) {
            dev = UUID.randomUUID().toString();
            prefs.edit().putString("device_id", dev).apply();
        }
        try {
            JSONObject b = new JSONObject().put("client_id", CLIENT_ID)
                    .put("scope", SCOPE)
                    .put("device_id", dev).put("device_model", "ytlr::");
            JSONObject o = new JSONObject(Http.postJson(DEVICE_CODE_URL, ytHeaders(), b.toString()));
            return new Code(o.getString("user_code"), o.optString("verification_url", "https://www.google.com/device"),
                    o.getString("device_code"), o.optInt("interval", 5),
                    System.currentTimeMillis() + o.optInt("expires_in", 1800) * 1000L);
        } catch (JSONException e) {
            throw new IOException(e);
        }
    }

    @Override
    public boolean pollCode(Code c) throws IOException {
        try {
            JSONObject b = new JSONObject().put("client_id", CLIENT_ID).put("client_secret", CLIENT_SECRET)
                    .put("code", c.deviceCode).put("grant_type", "http://oauth.net/grant_type/device/1.0");
            JSONObject o = new JSONObject(Http.postJson(TOKEN_URL, ytHeaders(), b.toString()));
            String err = o.optString("error", "");
            if (err.equals("authorization_pending") || err.equals("slow_down")) return false;
            if (!err.isEmpty()) throw new IOException(err.equals("expired_token") ? "The code expired." : err);
            storeTokens(o);
            fetchAccountName();
            return true;
        } catch (JSONException e) {
            throw new IOException(e);
        }
    }

    private static Map<String, String> ytHeaders() {
        Map<String, String> h = new HashMap<>();
        h.put("User-Agent", Http.TV_UA);
        h.put("Origin", "https://www.youtube.com");
        h.put("Referer", "https://www.youtube.com/tv");
        return h;
    }

    private void storeTokens(JSONObject o) {
        android.content.SharedPreferences.Editor e = prefs.edit();
        e.putString("access_token", o.optString("access_token"));
        e.putLong("expires_at", System.currentTimeMillis() + (o.optInt("expires_in", 3600) - 120) * 1000L);
        String rt = o.optString("refresh_token", "");
        if (!rt.isEmpty()) e.putString("refresh_token", rt);
        e.apply();
    }

    /** A valid access token (refreshed when it is about to expire), or null when signed out. */
    private synchronized String accessToken() throws IOException {
        String rt = prefs.getString("refresh_token", null);
        if (rt == null) return null;
        if (System.currentTimeMillis() < prefs.getLong("expires_at", 0)) return prefs.getString("access_token", null);
        try {
            JSONObject b = new JSONObject().put("client_id", CLIENT_ID).put("client_secret", CLIENT_SECRET)
                    .put("refresh_token", rt).put("grant_type", "refresh_token");
            JSONObject o = new JSONObject(Http.postJson(TOKEN_URL, ytHeaders(), b.toString()));
            if (o.has("error")) {
                Log.w(TAG, "token refresh: " + o.optString("error"));
                if ("invalid_grant".equals(o.optString("error"))) signOut();
                return null;
            }
            storeTokens(o);
            return o.optString("access_token");
        } catch (Http.Error e) {
            if (e.code == 400 || e.code == 401) {
                Log.w(TAG, "refresh rejected; signing out: " + e.body);
                signOut();
                return null;
            }
            throw e;
        } catch (JSONException e) {
            throw new IOException(e);
        }
    }

    private void fetchAccountName() {
        try (Http.Response r = call("account/accounts_list", tvContext(new JSONObject()), true)) {
            final String[] name = {""}, photo = {""};
            JsonReader jr = new JsonReader(new InputStreamReader(r.body, StandardCharsets.UTF_8));
            JsonScan.scan(jr, new HashSet<>(Arrays.asList("accountItemRenderer", "accountItem")), NONE, SKIP,
                    new JsonScan.Sink() {
                        @Override
                        public void onValue(String key, String n, JSONObject v) {
                            if (name[0].isEmpty()) {
                                name[0] = JsonScan.text(v.optJSONObject("accountName"));
                                // the account picture: the largest thumbnail of accountPhoto
                                org.json.JSONArray th = v.optJSONObject("accountPhoto") == null ? null
                                        : v.optJSONObject("accountPhoto").optJSONArray("thumbnails");
                                if (th != null && th.length() > 0) {
                                    String u = th.optJSONObject(th.length() - 1).optString("url", "");
                                    photo[0] = u.startsWith("//") ? "https:" + u : u;
                                }
                            }
                        }
                    });
            prefs.edit().putString("account", name[0]).putString("avatar", photo[0]).apply();
        } catch (IOException e) {
            Log.w(TAG, "account name: " + e.getMessage());
        }
    }

    @Override
    public void refreshSession() throws IOException {
        if (accessToken() != null && prefs.getString("avatar", "").isEmpty()) fetchAccountName();
    }

    private static final java.util.concurrent.ExecutorService WATCH_IO = java.util.concurrent.Executors.newSingleThreadExecutor(new java.util.concurrent.ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "ctv-yt-watch");
            t.setDaemon(true);
            return t;
        }
    });
    private static final java.util.concurrent.atomic.AtomicBoolean WATCH_BUSY = new java.util.concurrent.atomic.AtomicBoolean();
    /** Watch-time URL per video, from the signed-in player answer. A miss is not cached. */
    private static final Map<String, String> WATCH_URL = java.util.Collections.synchronizedMap(new java.util.LinkedHashMap<String, String>(32, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, String> e) {
            return size() > 24;
        }
    });
    /** When a watch-time report for a video may be tried again, after a failure. */
    private static final Map<String, Long> WATCH_FAIL = java.util.Collections.synchronizedMap(new HashMap<String, Long>());

    /**
     * Remembers a real watch (finished titles leave Continue watching, so this is what Home expands next) and, when
     * signed in, tells YouTube's own watch-time endpoint. The embed player is not the account, so without this the
     * account's recommendations never move. Best effort, off the playback thread, and never retried in a loop.
     */
    @Override
    public void noteWatch(Item it, long posMs, long durMs) {
        if (!videoId(it) || it.kind != Item.VIDEO || posMs < 30_000) return;
        rememberWatch(it);
        if (!signedIn()) return;
        final long end = posMs / 1000;
        final long prev = prefs.getLong("wt_" + it.id, 0);
        if (end < prev + 45) return;
        Long fail = WATCH_FAIL.get(it.id);
        if (fail != null && System.currentTimeMillis() < fail) return;
        if (!WATCH_BUSY.compareAndSet(false, true)) return;
        final Item item = it;
        final long pos = posMs, dur = durMs, previous = prev;
        WATCH_IO.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    reportWatch(item, pos, dur, previous);
                } finally {
                    WATCH_BUSY.set(false);
                }
            }
        });
    }

    private void reportWatch(Item it, long posMs, long durMs, long previous) {
        try {
            if (accessToken() == null) return;
            String base = watchBase(it.id);
            if (base == null || base.isEmpty()) {
                WATCH_FAIL.put(it.id, System.currentTimeMillis() + 120_000);
                return;
            }
            long end = posMs / 1000;
            long len = durMs > 0 ? Math.max(end, durMs / 1000) : end;
            StringBuilder u = new StringBuilder(base);
            if (u.indexOf("cpn=") < 0) u.append(u.indexOf("?") < 0 ? '?' : '&').append("cpn=").append(cpn());
            u.append("&cmt=").append(end).append("&rt=").append(Math.max(end, 1))
                    .append("&st=").append(Math.max(0, previous)).append("&et=").append(end)
                    .append("&len=").append(len).append("&state=playing&volume=100&muted=0");
            Map<String, String> h = new HashMap<>();
            h.put("User-Agent", Http.TV_UA);
            h.put("Origin", "https://www.youtube.com");
            h.put("Referer", "https://www.youtube.com/tv");
            String token = accessToken();
            if (token == null) return;
            h.put("Authorization", "Bearer " + token);
            try (Http.Response r = Http.open(u.toString(), h, null, null, true)) {
                prefs.edit().putLong("wt_" + it.id, end).apply();
                Log.i(TAG, "watchtime " + it.id + " to " + end + "s: HTTP " + r.code);
            }
        } catch (Http.Error e) {
            WATCH_FAIL.put(it.id, System.currentTimeMillis() + 120_000);
            Log.w(TAG, "watchtime " + it.id + ": HTTP " + e.code);
        } catch (IOException e) {
            WATCH_FAIL.put(it.id, System.currentTimeMillis() + 120_000);
            Log.w(TAG, "watchtime " + it.id + " failed");
        }
    }

    /** The signed-in player answer's watch-time URL for this video, or null. The URL itself is never logged. */
    private String watchBase(String videoId) throws IOException {
        String cached = WATCH_URL.get(videoId);
        if (cached != null) return cached;
        final String[] url = {""};
        JSONObject extra = new JSONObject();
        try {
            extra.put("videoId", videoId).put("contentCheckOk", true).put("racyCheckOk", true);
        } catch (JSONException e) {
            throw new IOException(e);
        }
        Set<String> cap = new HashSet<>(Arrays.asList("videostatsWatchtimeUrl"));
        Set<String> skip = new HashSet<>(Arrays.asList("streamingData", "playerConfig", "storyboards", "captions",
                "annotations", "attestation", "adPlacements", "playerAds", "endscreen", "thumbnail", "thumbnails",
                "responseContext", "frameworkUpdates"));
        try (Http.Response r = call("player", tvContext(extra), true)) {
            JsonReader jr = new JsonReader(new InputStreamReader(r.body, StandardCharsets.UTF_8));
            JsonScan.scan(jr, cap, NONE, skip, new JsonScan.Sink() {
                @Override
                public void onValue(String key, String name, JSONObject v) {
                    String u = v.optString("baseUrl", "");
                    if (!u.isEmpty() && url[0].isEmpty()) url[0] = u.startsWith("//") ? "https:" + u : u;
                }
            });
        }
        if (url[0].isEmpty()) return null;
        WATCH_URL.put(videoId, url[0]);
        return url[0];
    }

    private static String cpn() {
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
        StringBuilder b = new StringBuilder(16);
        java.util.Random rnd = new java.util.Random();
        for (int i = 0; i < 16; i++) b.append(alphabet.charAt(rnd.nextInt(alphabet.length())));
        return b.toString();
    }

    /** The account's watch history (FEhistory), newest first. */
    @Override
    public List<Item> history() throws IOException {
        if (!signedIn()) return new java.util.ArrayList<>();
        Item.Page p = load(new Nav("FEhistory", "History"));
        for (Item.Shelf sh : p.shelves) if (!sh.items.isEmpty()) return sh.items;
        return new java.util.ArrayList<>();
    }

    @Override
    public boolean signedIn() {
        return prefs.getString("refresh_token", null) != null;
    }

    @Override
    public void signOut() {
        prefs.edit().remove("refresh_token").remove("access_token").remove("expires_at").remove("account").remove("avatar")
                .remove("on_behalf").apply();
        forgetProfile();
    }

    // ---------------------------------------------------------------------------------- profiles

    @Override public boolean hasProfiles() { return true; }

    /**
     * The account's channels as profiles: its own and any brand-account channels it manages, from the TV app's
     * account switcher (account/accounts_list). A brand channel is used through context.user.onBehalfOfUser.
     */
    @Override
    public List<Profile> profiles() throws IOException {
        final List<Profile> out = new ArrayList<>();
        if (accessToken() == null) return out;
        final String current = prefs.getString("on_behalf", "");
        try (Http.Response r = call("account/accounts_list", tvContext(new JSONObject()), true)) {
            JsonReader jr = new JsonReader(new InputStreamReader(r.body, StandardCharsets.UTF_8));
            JsonScan.scan(jr, new HashSet<>(Arrays.asList("accountItemRenderer", "accountItem")), NONE, SKIP,
                    new JsonScan.Sink() {
                        @Override
                        public void onValue(String key, String n, JSONObject v) {
                            String name = JsonScan.text(v.optJSONObject("accountName"));
                            String photo = "";
                            org.json.JSONArray th = v.optJSONObject("accountPhoto") == null ? null
                                    : v.optJSONObject("accountPhoto").optJSONArray("thumbnails");
                            if (th != null && th.length() > 0) {
                                String u = th.optJSONObject(th.length() - 1).optString("url", "");
                                photo = u.startsWith("//") ? "https:" + u : u;
                            }
                            String pageId = "";
                            org.json.JSONArray tokens = JsonScan.path(v, "serviceEndpoint", "selectActiveIdentityEndpoint") == null ? null
                                    : JsonScan.path(v, "serviceEndpoint", "selectActiveIdentityEndpoint").optJSONArray("supportedTokens");
                            if (tokens != null) for (int i = 0; i < tokens.length(); i++) {
                                JSONObject pt = tokens.optJSONObject(i) == null ? null : tokens.optJSONObject(i).optJSONObject("pageIdToken");
                                if (pt != null && !pt.optString("pageId").isEmpty()) pageId = pt.optString("pageId");
                            }
                            boolean active = pageId.equals(current) || (current.isEmpty() && v.optBoolean("isSelected") && pageId.isEmpty());
                            String id = pageId.isEmpty() ? "main" : pageId;
                            for (Profile o : out) if (o.id.equals(id)) return;
                            out.add(new Profile(id, name, photo, false, active, "", pageId));
                        }
                    });
        }
        Log.i(TAG, "profiles: " + out.size());
        return out;
    }

    @Override
    public void selectProfile(Profile p, String pin) {
        prefs.edit().putString("on_behalf", p.data).putString("account", p.name).putString("avatar", p.avatar).apply();
        rememberProfile(p);
    }
}
